#!/usr/bin/env python3
"""Cattail Run Data Campus - Phase 1 foundation strategy design engine v2.
All parameters from the project data room. Computes the 36 foundation designs,
the improved-pad programme and the campus cost, and writes all deliverables.
"""
import json, math, os, csv

ROOT = "/filesystem/dc_structural__foundation_strategy__blind"
P = os.path.join(ROOT, "project")

# ================= inputs =================
FS_OCC = {"CR-P1":3.5,"CR-P2":3.5,"CR-P3":3.5,"CR-P4":3.0,"CR-P5":2.5,"CR-P6":3.5}
OCC = {"CR-P1":"Light Industrial, Public","CR-P2":"Light Industrial, Public",
       "CR-P3":"Light Industrial, Public","CR-P4":"Apartments, Office",
       "CR-P5":"Warehouse","CR-P6":"Light Industrial, Public"}
EXPOSURE = {k: (["F3","W1","C1"] if k=="CR-P5" else ["F1","W1","C1"]) for k in FS_OCC}
SULFATE = {"CR-P1":0.14,"CR-P2":0.23,"CR-P3":0.07,"CR-P4":0.11,"CR-P5":0.05,"CR-P6":0.26}
SULF_CLASS = {"CR-P1":"S0","CR-P2":"S1","CR-P3":"S0","CR-P4":"S0","CR-P5":"S0","CR-P6":"S1"}
WCM = {"F1":0.50,"F2":0.50,"F3":0.45,"W1":0.50,"W2":0.45,"C0":None,"C1":0.50,"C2":0.40}
FCMIN = {"F1":3000,"F2":3000,"F3":3000,"W1":3000,"W2":3000,"C0":2500,"C1":2500,"C2":5000}
SULFC = {"S0":(None,2500),"S1":(0.50,4000),"S2":(0.45,4500)}
GW  = {"CR-P1":8.0,"CR-P2":9.0,"CR-P3":19.0,"CR-P4":8.0,"CR-P5":21.0,"CR-P6":8.5}
GAMMA1,PHI1,C1K = 118.0,26.0,0.25
ES = {"CR-P1":[110,1500,3500],"CR-P2":[85,1400,3400],"CR-P3":[210,1700,3700],
      "CR-P4":[130,1600,3600],"CR-P5":[250,1800,3800],"CR-P6":[95,1450,3450]}
I0  = {"CR-P1":6.0,"CR-P2":13.5,"CR-P3":5.5,"CR-P4":6.0,"CR-P5":4.5,"CR-P6":14.0}
I77 = {"CR-P1":12.5,"CR-P2":9.0,"CR-P3":7.0,"CR-P4":9.5,"CR-P5":5.5,"CR-P6":6.5}
T2  = {"CR-P1":14.0,"CR-P2":12.0,"CR-P3":16.0,"CR-P4":15.0,"CR-P5":18.0,"CR-P6":13.0}
STATIONS = ["F1","F2","F3","F4","F5","W1"]
STA_FT = {"F1":0.0,"F2":24.0,"F3":44.0,"F4":60.0,"F5":72.0,"W1":77.0}
COL_IN = {"F1":24,"F2":26,"F3":28,"F4":26,"F5":22}
WALL_L,WALL_T = 24.0,12.0
BDEPTH_IN = 42.0            # AHJ amendment 3 (AFI-100 1981-2010 interp = 507 F-days > 500)
AFI100_CUR, AFI100_SUP, FROST_IN = 507, 416, 42.0
PIER_D,PIER_SP,PIER_DMIN,PIER_DMAX,QCAP = 30.0,12.0,8,25,18000.0
NS,RA_MIN,RA_MAX_STAG = 10.0,0.33,0.463
KG = {"CR-P1":165.0,"CR-P2":140.0,"CR-P3":210.0,"CR-P4":195.0,"CR-P5":230.0,"CR-P6":155.0}
MOBIL,PIER_LF,PLAT_SY,MODTEST = 40000.0,28.0,2.40,9500.0
CP_CONC = {3000:182,4000:196,4500:211,5000:228}
CP_STEEL,CP_EXC,CP_BF,CP_DEW = 1.42,38.0,46.0,4200.0
FC_AVAIL = [3000,4000,4500,5000]
TOT_SETTLE_IN = 1.0
ANG_LIMIT = 1/500.0
FLOOR_MIN_IN, STRIP_MIN_IN, TMIN, GRID = 24.0,20.0,12.0,3.0
BAR4_A = 0.196
AP_PIER_FT2 = math.pi/4*(PIER_D/12.0)**2

def pad_wcm_fcmin(pad):
    wcm, fc = [], []
    for c in EXPOSURE[pad] + [SULF_CLASS[pad]]:
        w, f = SULFC[c] if c in SULFC else (WCM.get(c), FCMIN.get(c))
        if w is not None: wcm.append(w)
        if f is not None: fc.append(f)
    return min(wcm), min(fc)

def s1_base_ft(pad, sta):
    return round(I0[pad] + (I77[pad]-I0[pad])*sta/77.0, 1)

LD = {}
def load(pad, tag, case):
    if pad not in LD:
        d = {}
        raw = open(os.path.join(P,"structural/AV-CR-2604_base_reactions.csv")).read()
        lines = [l for l in raw.splitlines(keepends=True)
                 if not l.strip().lstrip('"').startswith("#")]
        import io
        for r in csv.DictReader(io.StringIO("".join(lines))):
                if r["pad"]==pad:
                    d.setdefault(r["foundation_tag"],{})[r["load_case"]]=(
                        float(r["P_kips"]),float(r["Hx_kips"]),float(r["My_kipft"]))
        LD[pad] = d
    return LD[pad][tag][case]

# ================= bearing capacity =================
def N_51(phi):
    t = [(0,5.14,1.0,0.0),(5,6.5,1.6,0.5),(10,8.4,2.5,1.2),(15,11.0,3.9,2.7),
         (20,14.8,6.5,5.0),(25,20.7,10.7,10.9),(30,30.1,18.4,22.4),(35,46.1,33.3,48.0),
         (40,75.3,64.2,109.4),(45,172.0,174.0,400.0),(50,576.0,900.0,2900.0)]
    i = next(k for k in range(len(t)-1) if t[k][0] <= phi <= t[k+1][0])
    a,b = t[i],t[i+1]; f = (phi-a[0])/(b[0]-a[0])
    return a[1]+f*(b[1]-a[1]), a[2]+f*(b[2]-a[2]), a[3]+f*(b[3]-a[3])

def gw_factors(gw_ft, B_ft):
    Df = BDEPTH_IN/12.0
    if gw_ft < Df:
        return 0.5, 0.5
    cwr = 1.0 if gw_ft >= 1.5*B_ft+Df else 0.5+0.5*gw_ft/(1.5*B_ft+Df)
    return cwr, 1.0

def q_allow(pad, tag, B_in, L_in, fs, gw_ft):
    B, L = B_in/12.0, L_in/12.0
    Nc,Nq,Ng = N_51(PHI1)
    phi = math.radians(PHI1)
    sq = 1+(B/L)*(Nq/Nc) if L > B else 1.0
    sg = 1-0.4*min(B/L,1.0)
    cw,cwq = gw_factors(gw_ft, B)
    qsur = GAMMA1/1000.0*BDEPTH_IN/12.0
    # method 1: GEC6 general eq 5-14 with shape + gw factors
    q1 = C1K*Nc*sq + qsur*Nq*cwq + 0.5*(GAMMA1/1000.0)*B*Ng*sg*cw
    a1 = (q1-qsur)/fs
    # method 2: GEC6 general without shape factors (more conservative)
    q2 = C1K*Nc + qsur*Nq*cwq + 0.5*(GAMMA1/1000.0)*B*Ng*sg*cw
    a2 = (q2-qsur)/fs
    # method 3: Terzaghi/EM1110-1-1905 style N-factors, no shape factors
    Nq3 = math.exp(math.pi*math.tan(phi))*math.tan(math.pi/4+phi/2)**2
    Nc3 = (Nq3-1)/math.tan(phi)
    Ng3 = 2*(Nq3+1)*math.tan(phi)
    q3 = C1K*Nc3 + qsur*Nq3*cwq + 0.5*(GAMMA1/1000.0)*B*Ng3*cw
    a3 = (q3-qsur)/fs
    return min(a1,a2,a3), (a1,a2,a3)

# ================= settlement =================
def settle_layered(pad, tag, B_ft, L_ft, q_psf, z0_ft):
    """RFI-019 method: 2:1 stress spread, uniform 0.25-ft layers, to max(4B,40) ft
    below the bearing surface, pad-specific moduli (data report)."""
    deep = max(4.0*B_ft, 40.0)
    b1 = s1_base_ft(pad, STA_FT[tag]) - BDEPTH_IN/12.0
    es = ES[pad]
    s = 0.0; z = z0_ft
    while z < deep - 1e-9:
        zm = z + 0.125
        Es = es[0] if zm < b1 else (es[1] if zm < b1+T2[pad] else es[2])
        dsg = q_psf*B_ft*L_ft/((B_ft+zm)*(L_ft+zm))
        s += dsg*0.25/(Es*1000.0)
        z += 0.25
    return s*12.0

def pier_layout(tag, B_in):
    """Staggered grid, 30-in piers, 12-in min clear. Returns (count, Ra)."""
    Lft = WALL_L if tag=="W1" else B_in/12.0
    Bft = B_in/12.0
    S = PIER_D/12.0 + PIER_SP/12.0            # 3.5 ft c-c
    ry = math.sqrt(3)/2*S                       # 3.031 ft row spacing
    r0 = PIER_D/24.0                            # 1.25 ft edge margin
    n = 0
    y = r0
    while y + r0 <= Bft + 1e-6:
        off = 0.0 if (n_rows_even := 0) or True else 0
        cnt = 0
        x = r0 + (0.0 if n % 2 == 0 else S/2.0)
        while x + r0 <= Lft + 1e-6:
            cnt += 1
            x += S
        n += cnt
        y += ry
    if n == 0:
        n = 1
    Ra = min(n*AP_PIER_FT2/(Bft*Lft), RA_MAX_STAG + 0.02)
    return n, Ra

def settle_improved(pad, tag, B_in, q_psf, Ra, dt):
    ns = NS
    qg = q_psf*ns/(ns*Ra - Ra + 1.0)
    qs = q_psf*(1.0-Ra)/(ns*Ra - Ra + 1.0)
    B_ft, L_ft = B_in/12.0, (WALL_L if tag=="W1" else B_in/12.0)
    suz = (qg/144.0)/KG[pad]
    slz = settle_layered(pad, tag, B_ft, L_ft, qs, dt)
    return suz+slz, qg, qs

# ================= structural sizing =================
def size_footing(pad, tag, B_in, P_u, fc, is_wall, L_in=None):
    """thickness (3-in) by two-way & one-way shear (phi=0.65), flexure ratio."""
    L_ft = (L_in or B_in)/12.0
    a = (WALL_T/12.0) if is_wall else COL_IN[tag]/12.0
    B_ft = B_in/12.0
    q_u = P_u*1000.0/(B_ft*L_ft)/1000.0  # kips/sf
    t = TMIN
    while t <= 96:
        d = t-4.0
        bw = 2.0*(B_ft+a*0+(B_ft - a)*0)*0  # placeholder
        bw = 2.0*((B_ft-a)*12.0 + (L_ft-a)*12.0) if not is_wall else 2.0*((B_ft-a)*12.0 + (L_ft-a)*12.0)
        Vcap = 0.65*2.0*math.sqrt(fc)*bw*d/1000.0
        Vu = P_u - q_u*(B_ft*L_ft)
        Vu = P_u - q_u*a*a
        ok2 = Vcap >= Vu
        b1w = B_ft - a/2.0 - d/12.0
        Vcap1 = 0.65*2.0*math.sqrt(fc)*12.0*d/1000.0
        Vu1 = q_u*b1w*1.0
        ok1 = Vcap1 >= Vu1 or b1w <= 0.0
        if ok2 and ok1:
            break
        t += GRID
    if t > 96: t = 96
    d = t-4.0
    if is_wall:
        M = q_u*(B_ft-a)**2/8.0            # kip-ft per ft of strip
        rho = M*12.0/(0.9*60000.0*(12.0)*d)  # A_s(in2)/ft over (12*d) per ft
    else:
        M = q_u*(B_ft-a)**2/8.0*(L_ft)     # kip-ft (per width B)
        rho = M*12.0/(0.9*60000.0*(B_ft*12.0)*d)
    rho = max(rho, 0.0018)
    return t, rho

# ================= per-pad design =================
def design_pad(pad, improved, dt=8):
    fs, gw = FS_OCC[pad], GW[pad]
    wcm, fmin = pad_wcm_fcmin(pad)
    fc = min([f for f in FC_AVAIL if f >= fmin])
    out = {"pad":pad, "improved":improved, "fc":fc, "wcm":wcm, "dt":dt}
    results = {}
    for tag in STATIONS:
        P_S = load(pad, tag, "SERVICE_D_PLUS_L")[0]
        P_U = load(pad, tag, "STRENGTH_1.2D_1.6L")[0]
        is_wall = tag == "W1"
        L_in = int(round(WALL_L*12.0)) if is_wall else None
        min_w = STRIP_MIN_IN if is_wall else FLOOR_MIN_IN
        # e requirement for wall
        M_S = load(pad, tag, "SERVICE_D_PLUS_L_PLUS_W")[2] if is_wall else 0.0
        B_wreq = int(math.ceil((M_S/P_S)*6.0*12.0/GRID))*GRID if is_wall else 0
        start = int(max(min_w, B_wreq if is_wall else min_w)) // int(GRID) * int(GRID)
        found = None
        for w in range(start, 360+1, int(GRID)):
            B_ft = w/12.0; L_ft = WALL_L if is_wall else B_ft
            q = P_S*1000.0/(B_ft*L_ft)          # psf net service
            qa, _ = q_allow(pad, tag, w, (L_in or w), fs, gw)
            if q > qa: continue
            t, rho = size_footing(pad, tag, w, P_U, fc, is_wall, L_in)
            if not improved:
                s = settle_layered(pad, tag, B_ft, L_ft, q, 0.0)
                if s > TOT_SETTLE_IN + 1e-9: continue
                found = {"B_in":w, "L_in":L_in or w, "t_in":t, "rho":rho, "q":q,
                         "qa":qa, "s":s, "suz":None, "qg":None, "qs":None, "Ra":None}
            else:
                n, Ra = pier_layout(tag, w)
                Ra = min(Ra, RA_MAX_STAG)
                s, qg, qs = settle_improved(pad, tag, w, q, Ra, dt)
                if qg > QCAP: continue
                if s > TOT_SETTLE_IN + 1e-9: continue
                found = {"B_in":w, "L_in":L_in or w, "t_in":t, "rho":rho, "q":q,
                         "qa":qa, "s":s, "qg":qg, "qs":qs, "Ra":Ra, "n_piers":n}
            if found: break
        if found is None:
            found = {"B_in":360, "L_in":L_in or 360, "t_in":96, "rho":0.003,
                     "q":0.0, "qa":0.0, "s":9.9, "feasible":False}
        found["feasible"] = found.get("qa",0) > 0 or "qa" in found and found["qa"]>0
        results[tag] = found
    # pier totals + stability
    piers = {tag: results[tag].get("n_piers", 0) for tag in STATIONS}
    out["f"] = results
    if improved:
        out["piers"] = piers
        out["pier_lf"] = sum(piers.values())*dt
        out["plan_area_sy"] = sum((r["B_in"]/12.0)*(r["L_in"]/12.0) for r in results.values())/9.0
    st = wall_stability(pad, results)
    out["stability"] = st
    return out

def wall_stability(pad, results):
    P_S = load(pad,"W1","SERVICE_D_PLUS_L")[0]
    M_S = load(pad,"W1","SERVICE_D_PLUS_L_PLUS_W")[2]
    P_06 = load(pad,"W1","0.6D_PLUS_W")[0]
    H_06 = load(pad,"W1","0.6D_PLUS_W")[1]
    P_D  = load(pad,"W1","DEAD_ONLY")[0]
    U_W  = abs(load(pad,"W1","UPLIFT_W")[0])
    B_ft = results["W1"]["B_in"]/12.0
    L_ft = WALL_L
    t_ft = results["W1"]["t_in"]/12.0
    Df = BDEPTH_IN/12.0
    e = M_S/P_S
    Wc = B_ft*L_ft*t_ft*150.0/1000.0
    Ws = max(0.0, B_ft - WALL_T/12.0)*L_ft*Df*GAMMA1/1000.0
    td = math.tan(math.radians(2.0*PHI1/3.0))
    Kp = (1+math.sin(math.radians(PHI1)))/(1-math.sin(math.radians(PHI1)))
    Rp = 0.5*Kp*GAMMA1*Df*Df/2.0/1000.0*L_ft
    fs_slide = (P_06*td + 0.5*Rp)/H_06
    fs_up = 0.6*(P_D + Wc + Ws)/U_W
    return {"e_ft":e, "fs_slide":fs_slide, "fs_up":fs_up,
            "midthird_ok": e <= B_ft/6.0, "Wc":Wc, "Ws":Ws}

# ================= costs =================
def pad_cost(out):
    tag_f = out["f"]
    conc_v = 0.0; rebar_lb = 0.0; exc_v = 0.0
    t_max = max(tag_f[t]["t_in"] for t in STATIONS)/12.0
    d_exc = BDEPTH_IN/12.0 + t_max
    for tag in STATIONS:
        o = tag_f[tag]
        B_ft, L_ft = o["B_in"]/12.0, o["L_in"]/12.0
        t_ft = o["t_in"]/12.0
        we, le = B_ft+2.0, L_ft+2.0
        h = d_exc
        V = we*le*min(4.0, h)
        if h > 4.0:
            hb = h-4.0
            V += (we+3.0*hb)*(le+3.0*hb)*hb
        exc_v += V
        conc = B_ft*L_ft*t_ft
        conc_v += conc
        rebar_lb += 2.0*o["rho"]*conc*490.0
    backfill = exc_v - conc_v
    gw = GW[out["pad"]]
    dew_days = math.ceil(3.0*max(0.0, d_exc-gw))
    c = {"conc":conc_v*CP_CONC[out["fc"]], "steel":rebar_lb*CP_STEEL,
         "exc":exc_v*CP_EXC, "bf":backfill*CP_BF, "dew":dew_days*CP_DEW}
    total = sum(c.values())
    if out["improved"]:
        c["piers"] = out["pier_lf"]*PIER_LF
        c["plat"] = out["plan_area_sy"]*PLAT_SY
        c["modtest"] = MODTEST
        total += c["piers"] + c["plat"] + MODTEST
    c.update({"concrete_yd3":conc_v, "rebar_lb":rebar_lb, "exc_yd3":exc_v,
              "backfill_yd3":backfill, "dew_days":dew_days, "subtotal":total})
    out["cost"] = c
    return total

if __name__ == "__main__":
    for pad in FS_OCC:
        for imp in (False, True):
            for dt in (8,12,16,20,25):
                out = design_pad(pad, imp, dt)
                feas = all(out["f"][t].get("qa",0) > 0 and out["f"][t]["s"] <= TOT_SETTLE_IN for t in STATIONS)
                c = pad_cost(out)
                print(f"{pad} imp={int(imp)} dt={dt} feas={feas} cost={c:,.0f} ",
                      {t: (out['f'][t]['B_in'], round(out['f'][t]['s'],2)) for t in STATIONS})
