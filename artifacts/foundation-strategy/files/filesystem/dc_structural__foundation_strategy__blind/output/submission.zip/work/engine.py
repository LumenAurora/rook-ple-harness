#!/usr/bin/env python3
# Cattail Run Data Campus - Phase 1 foundation strategy: complete design engine + deliverables.
import json, math, os, csv, zipfile, itertools

ROOT = "/filesystem/dc_structural__foundation_strategy__blind"
P = os.path.join(ROOT, "project")

# ---------------- input data (from data room) ----------------
FS_OCC = {"CR-P1": 3.5, "CR-P2": 3.5, "CR-P3": 3.5, "CR-P4": 3.0, "CR-P5": 2.5, "CR-P6": 3.5}
OCC = {"CR-P1": "Light Industrial, Public", "CR-P2": "Light Industrial, Public",
       "CR-P3": "Light Industrial, Public", "CR-P4": "Apartments, Office",
       "CR-P5": "Warehouse", "CR-P6": "Light Industrial, Public"}
EXPOSURE = {k: (["F3","W1","C1"] if k == "CR-P5" else ["F1","W1","C1"]) for k in FS_OCC}
SULFATE = {"CR-P1": 0.14, "CR-P2": 0.23, "CR-P3": 0.07, "CR-P4": 0.11, "CR-P5": 0.05, "CR-P6": 0.26}
# UFGS 03 30 00 2.5.2.4: S1 w/cm<=0.50 fc>=4000; S2 w/cm<=0.45 fc>=4500
SULFATE_CLASS = {"CR-P1": "S0", "CR-P2": "S1", "CR-P3": "S0", "CR-P4": "S0", "CR-P5": "S0", "CR-P6": "S1"}
SULF_LIMIT = {"S0": (None, 2500), "S1": (0.50, 4000), "S2": (0.45, 4500)}
# UFGS 03 30 00 freeze-thaw/water/corrosion (2.5.2.1/2): F1 .50/3000, F3 .45/3000, W1 .50/3000, C1 .50/2500
WCM = {"F1": 0.50, "F2": 0.50, "F3": 0.45, "W1": 0.50, "W2": 0.45, "C0": None, "C1": 0.50, "C2": 0.40}
FC_MIN_EXP = {"F1": 3000, "F2": 3000, "F3": 3000, "W1": 3000, "W2": 3000, "C0": 2500, "C1": 2500, "C2": 5000}
def pad_wcm_fcmin(pad):
    wcm, fc = [], []
    for c in EXPOSURE[pad] + [SULFATE_CLASS[pad]]:
        w, f = SULF_LIMIT[c] if c in SULF_LIMIT else (WCM.get(c), FC_MIN_EXP.get(c))
        if w is not None: wcm.append(w)
        if f is not None: fc.append(f)
    return min(wcm), min(fc)
GW = {"CR-P1": 8.0, "CR-P2": 9.0, "CR-P3": 19.0, "CR-P4": 8.0, "CR-P5": 21.0, "CR-P6": 8.5}
GAMMA1, PHI1, C1K = 118, 26.0, 0.25
ES = {"CR-P1": [110,1500,3500], "CR-P2": [85,1400,3400], "CR-P3": [210,1700,3700],
      "CR-P4": [130,1600,3600], "CR-P5": [250,1800,3800], "CR-P6": [95,1450,3450]}
I0  = {"CR-P1":6.0,"CR-P2":13.5,"CR-P3":5.5,"CR-P4":6.0,"CR-P5":4.5,"CR-P6":14.0}
I77 = {"CR-P1":12.5,"CR-P2":9.0,"CR-P3":7.0,"CR-P4":9.5,"CR-P5":5.5,"CR-P6":6.5}
T2  = {"CR-P1":14.0,"CR-P2":12.0,"CR-P3":16.0,"CR-P4":15.0,"CR-P5":18.0,"CR-P6":13.0}
STATIONS = ["F1","F2","F3","F4","F5","W1"]
STA_FT = {"F1":0.0,"F2":24.0,"F3":44.0,"F4":60.0,"F5":72.0,"W1":77.0}
COL_IN = {"F1":24,"F2":26,"F3":28,"F4":26,"F5":22}
WALL_L, WALL_T = 24.0, 12.0
BEARING_DEPTH_IN = 42.0          # AHJ amendment 3: AFI100 (1981-2010) interpolated 507 > 500 F-days
AFI_100_CUR = 507               # Lincoln VA USC00444909, 1981-2010 rtp product, interp 90yr(491)/130yr(556)
AFI_100_SUP = 416               # 1951-1980 product
# KGS proposal
PIER_D, PIER_SP, PIER_DMIN, PIER_DMAX, QPIER_CAP = 30, 12, 8, 25, 18000.0
NS, RA_MIN = 10.0, 0.33
KG = {"CR-P1":165.0,"CR-P2":140.0,"CR-P3":210.0,"CR-P4":195.0,"CR-P5":230.0,"CR-P6":155.0}
MOBIL, PIER_LF, PLAT_SY, MODTEST = 40000.0, 28.0, 2.40, 9500.0
# bid schedule
CP_CONC = {3000:182, 4000:196, 4500:211, 5000:228}
CP_STEEL, CP_EXC, CP_BF, CP_DEW = 1.42, 38.0, 46.0, 4200.0
FC_AVAIL = [3000, 4000, 4500, 5000]
# limits
TOT_SETTLE_LIMIT_IN = 1.0
ANG_LIMIT = 1.0/500.0
FLOOR_MIN_IN = 24.0            # UFC 2-4.7.1 individual footings
STRIP_MIN_IN = 20.0           # max(18, wall+8)
TMIN_IN = 12.0
GRID_IN = 3.0

def s1_base_ft(pad, sta):
    return round(I0[pad] + (I77[pad]-I0[pad])*sta/77.0, 1)

# ---------------- loads ----------------
def loads(pad):
    d = {}
    with open(os.path.join(P, "structural/AV-CR-2604_base_reactions.csv")) as f:
        for r in csv.DictReader(f):
            if r["pad"] == pad:
                d.setdefault(r["foundation_tag"], {})[r["load_case"]] = (
                    float(r["P_kips"]), float(r["Hx_kips"]), float(r["My_kipft"]))
    return d

# ---------------- bearing capacity ----------------
def N_51(phi):  # GEC6 Table 5-1
    t = [(0,5.14,1.0,0.0),(5,6.5,1.6,0.5),(10,8.4,2.5,1.2),(15,11.0,3.9,2.7),
         (20,14.8,6.5,5.0),(25,20.7,10.7,10.9),(30,30.1,18.4,22.4),(35,46.1,33.3,48.0),
         (40,75.3,64.2,109.4),(45,172.0,174.0,400.0),(50,576.0,900.0,2900.0)]
    i = next(k for k in range(len(t)-1) if t[k][0] <= phi <= t[k+1][0])
    a, b = t[i], t[i+1]; f = (phi-a[0])/(b[0]-a[0])
    return a[1]+f*(b[1]-a[1]), a[2]+f*(b[2]-a[2]), a[3]+f*(b[3]-a[3])

def gw_factors(gw_ft, B_ft):
    Df = BEARING_DEPTH_IN/12.0
    if gw_ft >= Df:
        cwr = min(1.0, 0.5 + 0.5*min(gw_ft, 1.5*B_ft+Df)/(1.5*B_ft+Df))
        cwr = 1.0 if gw_ft >= 1.5*B_ft+Df else cwr
        return cwr, 1.0
    return 0.5, 0.5

def q_allow_methods(pad, tag, w_in, L_in, fs, gw_ft):
    B = w_in/12.0; L = L_in/12.0
    phi = math.radians(PHI1); c = C1K
    # 1) GEC6 general (AASHTO N-factors, shape, gw)
    Nc, Nq, Ng = N_51(PHI1)
    sq = 1 + (B/L)*(Nq/Nc) if L > B else 1.0
    sg = 1 - 0.4*min(B/L, 1.0)
    cw, cwq = gw_factors(gw_ft, B)
    q = GAMMA1/1000.0 * BEARING_DEPTH_IN/12.0
    qult1 = c*Nc*sq + q*Nq*cwq + 0.5*(GAMMA1/1000.0)*B*Ng*sg*cw
    a1 = (qult1 - q)/fs
    # 2) GEC6 general without shape factors (conservative)
    qult2 = c*Nc + q*Nq*cwq + 0.5*(GAMMA1/1000.0)*B*Ng*sg*cw
    a2 = (qult2 - q)/fs
    # 3) EM 1110-1-1905 style: Terzaghi-style factors, no shape
    Nq3 = math.exp(math.pi*math.tan(phi))*math.tan(math.pi/4 + phi/2)**2
    Nc3 = (Nq3-1)/math.tan(phi)
    Ng3 = 2*(Nq3+1)*math.tan(phi)
    qult3 = c*Nc3 + q*Nq3*cwq + 0.5*(GAMMA1/1000.0)*B*Ng3*cw
    a3 = (qult3 - q)/fs
    return min(a1, a2, a3)

# ---------------- settlement: layered elastic 2:1 ----------------
def settle_unimp(pad, B_ft, L_ft, q_psf, z0_ft):
    deep = max(4.0*B_ft, 40.0)
    b1 = s1_base_ft(pad, STA_FT["W1"] if L_ft == WALL_L else 0)  # placeholder, fixed by caller
    return None

def settle_layered(pad, tag, B_ft, L_ft, q_psf, z0_ft, use_stations=True):
    """z0_ft: depth below footing base where integration starts. Returns inches."""
    deep = max(4.0*B_ft, 40.0)
    sta = STA_FT[tag]
    b1 = s1_base_ft(pad, sta) - BEARING_DEPTH_IN/12.0          # ft below base
    es = ES[pad]
    s_ft = 0.0
    z = z0_ft
    while z < deep:
        zmid = z + 0.125
        if zmid < b1: Es = es[0]
        elif zmid < b1 + T2[pad]: Es = es[1]
        else: Es = es[2]
        dsg = q_psf * B_ft * L_ft / ((B_ft+zmid)*(L_ft+zmid))  # psf
        s_ft += dsg*0.25/(Es*1000.0)
        z += 0.25
    return s_ft*12.0

def settle_improved(pad, tag, B_ft, L_ft, q_psf, Ra, depth_t_ft):
    ns = NS
    qg = q_psf * ns/(ns*Ra - Ra + 1.0)
    qs = q_psf * (1.0 - Ra)/(ns*Ra - Ra + 1.0)
    suz_in = (qg/144.0)/KG[pad] * 12.0/12.0   # qg psi / kg(psi per in of settlement scale) -> see note
    # kg is lb/in^2 per in: suz(in) = qg(psi)/kg
    suz_in = (qg/144.0)/KG[pad]
    slz_in = settle_layered(pad, tag, B_ft, L_ft, qs, depth_t_ft)
    return suz_in + slz_in, qg, qs

# ---------------- structural sizing ----------------
def size_footing(pad, tag, B_ft, L_ft, P_u_kips, fc, is_wall):
    """Return (thickness_in, rho_req) for two-way/one-way shear + flexure."""
    a = (WALL_T/12.0) if is_wall else (COL_IN[tag]/12.0)
    w_in = B_ft*12.0
    d_target = None
    t = TMIN_IN
    while t <= 96:
        d = t - 4.0
        # two-way (punching) shear
        bw = ((B_ft + L_ft - a)*12.0) if not is_wall else ((B_ft + L_ft - a)*12.0)
        Vcap = 0.65*2.0*math.sqrt(fc)*bw*d/1000.0
        Vu = P_u_kips - (P_u_kips/(B_ft*L_ft))*a*a
        ok_punch = Vcap >= Vu
        # one-way shear (per ft width, critical face d/2 from edge)
        b1w = B_ft - a/2.0 - d/12.0
        Vcap1 = 0.65*2.0*math.sqrt(fc)*(12.0)*d/1000.0
        Vu1 = (P_u_kips/(B_ft*L_ft))*b1w*1.0
        ok_1w = Vcap1 >= Vu1
        if ok_punch and ok_1w:
            break
        t += 3
    if t > 96: t = 96
    d = t - 4.0
    q_u = P_u_kips*12.0/(B_ft*L_ft)   # kip/ft^2? -> ksf
    if is_wall:
        M = q_u*0.5*(B_ft/2 - a/2.0)**2      # kip-ft/ft (per linear ft)
        rho = M/(0.9*60000.0*1.0*d)         # A_s/ft / (12*d)
    else:
        M = q_u*( (B_ft - a)**2 / 8.0 )      # per width B, kip-ft
        rho = M/(0.9*60000.0*(B_ft*12.0)*d) # A_s per direction
    rho = max(rho, 0.0018)
    if t > 36.0:
        rho = max(rho, 0.0015)
    return t, rho

# ---------------- per-pad design ----------------
PARENT = {}
def design_pad(pad, improved, piers_depth=12):
    """Return per-pad dict with everything needed."""
    fs = FS_OCC[pad]
    gw = GW[pad]
    LD = loads(pad)
    wcm_lim, fc_min_exp = pad_wcm_fcmin(pad)
    # concrete = lowest available meeting durability and structural
    fc = min([f for f in FC_AVAIL if f >= fc_min_exp], key=lambda x: x)
    out = {"pad": pad, "improved": improved, "fc": fc, "wcm": wcm_lim,
           "sulf_class": SULFATE_CLASS[pad]}
    Ra, ns = RA_MIN, NS
    A_pier = math.pi/4*(PIER_D/12.0)**2
    S = PIER_D/12.0 + PIER_SP/12.0
    # staggered grid
    area_stag = A_pier
    stag_ratio = A_pier/(math.sqrt(3.0)/2.0*S*S)
    sq_ratio = A_pier/(S*S)
    qg_cap_Ra = min(sq_ratio, stag_ratio)
    found = {}
    for tag in STATIONS:
        P_S = LD[tag]["SERVICE_D_PLUS_L"][0]
        P_U = LD[tag]["STRENGTH_1.2D_1.6L"][0]
        is_wall = tag == "W1"
        L_ft = WALL_L if is_wall else None
        min_w = STRIP_MIN_IN if is_wall else FLOOR_MIN_IN
        if not improved:
            L_try = WALL_L if is_wall else None
            for w in range(int(max(min_w, 1)), 300+1, 3):
                Bf = w/12.0; Lf = WALL_L if is_wall else Bf
                q = P_S*1000.0/(Bf*Lf)
                qa = q_allow_methods(pad, tag, w, w if not is_wall else WALL_L*12.0, fs, gw)
                if q > qa*1.0: continue
                t, rho = size_footing(pad, tag, Bf, Lf, P_u=P_U, fc=fc, is_wall=is_wall)
                s = settle_layered(pad, tag, Bf, Lf, P_S*1000.0/(Bf*Lf)*0 + P_S*1000.0/(Bf*Lf), 0.0)
                if s > TOT_SETTLE_LIMIT_IN: continue
                found[tag] = {"B_in": w, "L_in": int(round(Lf*12.0)), "t_in": t, "rho": rho,
                              "q_psf": P_S*1000.0/(Bf*Lf), "q_allow": qa, "settle_in": s}
                break
            if tag not in found:
                # fall back largest
                w = 299
                Bf = w/12.0; Lf = WALL_L if is_wall else Bf
                t, rho = size_footing(pad, tag, Bf, Lf, P_U, fc, is_wall)
                found[tag] = {"B_in": w, "L_in": int(round(Lf*12.0)), "t_in": t, "rho": rho,
                              "q_psf": P_S*1000.0/(Bf*Lf), "q_allow": 0.0, "settle_in": 9.9}
        else:
            Ra_use = max(RA_MIN, min(sq_ratio, stag_ratio, 0.6))
            dt = piers_depth
            for w in range(int(max(min_w,1)), 300+1, 3):
                Bf = w/12.0; Lf = WALL_L if is_wall else Bf
                q = P_S*1000.0/(Bf*Lf)
                s, qg, qs = settle_improved(pad, tag, Bf, Lf, q, Ra_use, dt)
                if qg > QPIER_CAP: continue
                qa = q_allow_methods(pad, tag, w, w if not is_wall else WALL_L*12.0, fs, gw)
                if q > qa: continue
                t, rho = size_footing(pad, tag, Bf, Lf, P_u=P_U, fc=fc, is_wall=is_wall)
                found[tag] = {"B_in": w, "L_in": int(round(Lf*12.0)), "t_in": t, "rho": rho,
                              "q_psf": q, "q_allow": qa, "settle_in": s,
                              "qg_psf": qg, "qs_psf": qs, "Ra": Ra_use, "depth_ft": dt}
                break
            if tag not in found:
                found[tag] = {"B_in": 300, "L_in": int((WALL_L if is_wall else 300/12.0)*12.0),
                              "t_in": 96, "rho": 0.0025, "q_psf": 0.0, "q_allow": 0.0,
                              "settle_in": 9.9, "qg_psf": 9e9, "qs_psf": 0.0, "Ra": Ra_use, "depth_ft": dt}
        out[tag] = found[tag]
    # piers
    piers = {}
    if improved:
        for tag in STATIONS:
            Bf = out[tag]["B_in"]/12.0
            Lf = WALL_L if tag == "W1" else Bf
            nx = int(math.floor((Lf*12.0 - PIER_D)/PIER_SP + 1e-9)); nx = max(nx, 1)
            ny = 1
            piers[tag] = nx*ny
        out["piers"] = piers
        out["pier_lf_total"] = sum(piers.values())*piers_depth
    # W1 stability
    out["stability"] = wall_stability(pad, out)
    return out

def P_u(kips): return kips

def wall_stability(pad, out):
    LD = loads(pad)
    P_S = LD["W1"]["SERVICE_D_PLUS_L"][0]
    H_S = LD["W1"]["SERVICE_D_PLUS_L_PLUS_W"][1]
    M_S = LD["W1"]["SERVICE_D_PLUS_L_PLUS_W"][2]
    P_06 = LD["W1"]["0.6D_PLUS_W"][0]
    H_06 = LD["W1"]["0.6D_PLUS_W"][1]
    P_D = LD["W1"]["DEAD_ONLY"][0]
    U_W = LD["W1"]["UPLIFT_W"][0]
    Bf = out["W1"]["B_in"]/12.0
    Lf = WALL_L
    t = out["W1"]["t_in"]/12.0
    Df = BEARING_DEPTH_IN/12.0
    e = M_S/P_S
    W_conc = Bf*Lf*t*150.0/1000.0
    W_soil = (Bf - WALL_T/12.0)*Lf*Df*GAMMA1/1000.0
    tan_delta = math.tan(math.radians(2.0*PHI1/3.0))
    Kp = (1+math.sin(math.radians(PHI1)))/(1-math.sin(math.radians(PHI1)))
    Rp = 0.5*Kp*GAMMA1*(Df**2)/2.0/1000.0*Lf
    R_slide = P_06*tan_delta + 0.5*Rp
    fs_slide = R_slide/H_06
    fs_uplift = 0.6*(P_D + W_conc + W_soil)/abs(U_W)
    return {"e_ft": e, "fs_slide": fs_slide, "fs_uplift": fs_uplift,
            "midthird": e <= Bf/6.0,
            "W_conc": W_conc, "W_soil": W_soil, "H_06": H_06}

# ---------------- cost ----------------
def pad_cost(out):
    total = 0.0; conc_v = 0.0; rebar_w = 0.0
    t_max = max(out[t]["t_in"] for t in STATIONS)
    d_exc = BEARING_DEPTH_IN/12.0 + t_max/12.0
    for tag in STATIONS:
        o = out[tag]
        Bf = o["B_in"]/12.0; Lf = o["L_in"]/12.0
        t = o["t_in"]/12.0
        w_exc, l_exc = Bf+2.0, Lf+2.0
        A = w_exc*l_exc
        h = d_exc
        V = A*min(4.0, h)
        if h > 4.0:
            hb = h - 4.0
            V += (w_exc + 2*1.5*hb)*(l_exc + 2*1.5*hb)*hb
        conc = Bf*Lf*t
        conc_v += conc
        rho = o["rho"]
        rebar_w += 2.0*rho*conc*1728.0*490.0/1728.0*1.0/1.0  # lb
        # (ratio x volume ft3 x 490 pcf -> lb per direction; two mats => 2x)
        rebar_w *= 1.0
        out["V_exc"] = V
    backfill = out["V_exc"] - conc_v
    gw = GW[out["pad"]]
    dew_days = math.ceil(3.0*max(0.0, d_exc - gw))
    total = (conc_v*CP_CONC[str(out["fc"])] + rebar_w*CP_STEEL + out["V_exc"]*CP_EXC
             + backfill*CP_BF + dew_days*CP_DEW)
    out["costs"] = {"concrete_yd3": conc_v, "rebar_lb": rebar_w, "exc_yd3": out["V_exc"],
                    "backfill_yd3": backfill, "dew_days": dew_days,
                    "concrete": conc_v*CP_CONC[str(out["fc"])],
                    "rebar": rebar_w*CP_STEEL, "excavation": out["V_exc"]*CP_EXC,
                    "backfill": backfill*CP_BF, "dewatering": dew_days*CP_DEW}
    if out["improved"]:
        plat = sum((o["B_in"]/12.0)*(o["L_in"]/12.0) for o in (out[t] for t in STATIONS))
        out["costs"]["platform_sy"] = plat/9.0
        out["costs"]["platform"] = plat/9.0*PLAT_SY
        out["costs"]["pier_lf"] = out.get("pier_lf_total", 0.0)
        out["costs"]["piers"] = out["costs"]["pier_lf"]*PIER_LF
        out["costs"]["modtest"] = MODTEST
        total += out["costs"]["platform"] + out["costs"]["piers"] + MODTEST
    out["costs"]["subtotal"] = total
    return total

if __name__ == "__main__":
    import sys
    for pad in FS_OCC:
        for imp in (False, True):
            out = design_pad(pad, imp)
            c = pad_cost(out)
            print(pad, "improved" if imp else "spread", round(c, 0))
