#!/usr/bin/env python3
"""Cattail Run Data Campus - Phase 1 foundation strategy builder.
Computes all 36 foundation designs and writes the 6 deliverables + submission.zip.
All parameters sourced from the project data room (see design_basis narrative).
"""
import json, math, os, zipfile, datetime

ROOT = "/filesystem/dc_structural__foundation_strategy__blind"
OUT = os.path.join(ROOT, "output")
WORK = os.path.join(ROOT, "work")

# ---------------- constants from the documents ----------------
# UFC 3-220-01 (2012 c3) Table 2-3 building FS
FS_OCC = {"CR-P1": 3.5, "CR-P2": 3.5, "CR-P3": 3.5, "CR-P4": 3.0, "CR-P5": 2.5, "CR-P6": 3.5}
OCC = {"CR-P1": "Light Industrial, Public", "CR-P2": "Light Industrial, Public",
       "CR-P3": "Light Industrial, Public", "CR-P4": "Apartments, Office",
       "CR-P5": "Warehouse", "CR-P6": "Light Industrial, Public"}
EXPOSURE = {"CR-P1": ["F1", "W1", "C1"], "CR-P2": ["F1", "W1", "C1"],
            "CR-P3": ["F1", "W1", "C1"], "CR-P4": ["F1", "W1", "C1"],
            "CR-P5": ["F3", "W1", "C1"], "CR-P6": ["F1", "W1", "C1"]}
# EM 1110-2-2000 sulfate guide: <0.2% none; 0.2-0.5 moderate; 0.5-1.0 severe; >1.0 very severe
# UFGS 03 30 00: S0 none, S1 moderate, S2 severe
SULFATE = {"CR-P1": 0.14, "CR-P2": 0.23, "CR-P3": 0.07, "CR-P4": 0.11,
           "CR-P5": 0.05, "CR-P6": 0.26}
def sulfate_class(s):
    if s < 0.2: return "S0"
    if s < 0.5: return "S1"
    return "S2"
# w/cm and f'c limits per class (UFGS 03 30 00)
FC_MIN = {"S0": 3000, "S1": 4000, "S2": 5000}
MAX_WCM = {"CR-P1": 0.50, "CR-P2": 0.45, "CR-P3": 0.50, "CR-P4": 0.50,
           "CR-P5": 0.45, "CR-P6": 0.45}
FC_AVAILABLE = [3000, 4000, 4500, 5000]
CP_C = {"3000": 182, "4000": 196, "4500": 211, "5000": 228}
CP_REBAR = 1.42
CP_EXC = 38
CP_BACKFILL = 46
CP_DEWATER = 4200
# KGS proposal
PIER_D = 30  # in
MIN_CLEAR = 12  # in
DEPTH_MIN, DEPTH_MAX = 8, 25
QPIER_MAX = 18000
NS = 10          # GEC13 rigid footing
RA_MIN = 0.33   # GEC13 HITEC min replacement ratio
KG = {"CR-P1": 165.0, "CR-P2": 140.0, "CR-P3": 210.0, "CR-P4": 195.0,
      "CR-P5": 230.0, "CR-P6": 155.0}
MOBIL = 40000
PIER_UNIT = 28.0   # $/LF
PLATFORM_UNIT = 2.40  # $/SY
MODTEST_UNIT = 9500  # per improved pad
# geotechnical data report rev2
GW = {"CR-P1": 8.0, "CR-P2": 9.0, "CR-P3": 19.0, "CR-P4": 8.0, "CR-P5": 21.0, "CR-P6": 8.5}
GAMMA1, PHI1, C1_ = 118, 26.0, 0.25     # pcf, deg, ksf
GAMMA2, PHI2, C2_ = 126, 33.0, 0.0
GAMMA3, PHI3, C3_ = 132, 38.0, 0.0
ES = {"CR-P1": [110, 1500, 3500], "CR-P2": [85, 1400, 3400],
      "CR-P3": [210, 1700, 3700], "CR-P4": [130, 1600, 3600],
      "CR-P5": [250, 1800, 3800], "CR-P6": [95, 1450, 3450]}
# base of stratum I (ft below grade) at stations 0 and 77 + thickness of stratum II
I0 = {"CR-P1": 6.0, "CR-P2": 13.5, "CR-P3": 5.5, "CR-P4": 6.0, "CR-P5": 4.5, "CR-P6": 14.0}
I77 = {"CR-P1": 12.5, "CR-P2": 9.0, "CR-P3": 7.0, "CR-P4": 9.5, "CR-P5": 5.5, "CR-P6": 6.5}
T2 = {"CR-P1": 14.0, "CR-P2": 12.0, "CR-P3": 16.0, "CR-P4": 15.0, "CR-P5": 18.0, "CR-P6": 13.0}
STATIONS = {"F1": 0.0, "F2": 24.0, "F3": 44.0, "F4": 60.0, "F5": 72.0, "W1": 77.0}
COL_SIZE = {"F1": 24, "F2": 26, "F3": 28, "F4": 26, "F5": 22}
WALL_L, WALL_T = 24.0, 12.0

def load(pad, tag, case):
    import csv
    if "DATA" not in globals():
        d = {}
        with open(os.path.join(ROOT, "project/structural/AV-CR-2604_base_reactions.csv")) as f:
            for r in csv.DictReader(f):
                if r["pad"] == pad and r["foundation_tag"] == tag and r["load_case"] == case:
                    d[case] = (float(r["P_kips"]), float(r["Hx_kips"]), float(r["My_kipft"]))
        DATA = d
    return DATA[case]

def stratum1_base(pad, sta):
    t = round(I0[pad] + (I77[pad] - I0[pad]) * sta / 77.0, 1)
    return t  # ft below grade

# ---------------- bearing capacity ----------------
def n_factors(phi):
    """GEC6 Table 5-1 (AASHTO 1996) interpolation."""
    tab = [(0,5.14,1.0,0.0),(5,6.5,1.6,0.5),(10,8.4,2.5,1.2),(15,11.0,3.9,2.7),
           (20,14.8,6.5,5.0),(25,20.7,10.7,10.9),(30,30.1,18.4,22.4),(35,46.1,33.3,48.0),
           (40,75.3,64.2,109.4),(45,172.0,174.0,400.0),(50,576.0,900.0,2900.0)]
    if phi <= 25:
        i = 1 if phi <= 5 else 2
    else:
        i = 4 if phi <= 15 else (5 if phi <= 30 else 6)
    (a,anc,aqn,agn),(b,bnc,bqn,bgn) = tab[i-1], tab[i]
    f = (phi - a) / (b - a)
    return anc + f*(bnc-anc), aqn + f*(bqn-aqn), agn + f*(bgn-agn)

def gw_factors(depth_ft, B_ft, Bf_ft):
    """GEC6 eq 5-9 / 5-10. depth_ft = water table depth below grade; Bf = footing width."""
    DW, Df = depth_ft, Bf_ft
    if DW <= 0:
        return 0.5, 0.5
    if DW >= 1.5*B_ft + Df and DW > Df:
        return 1.0, 1.0
    CWr = 0.5 + 0.5 * min(DW, 1.5*B_ft + Df) / (1.5*B_ft + Df)
    CWq = 0.5 + 0.5 * min(DW, Df) / Df if Df > 0 else 1.0
    return min(CWr, 1.0), min(CWq, 1.0)

def q_allow_gsec6(pad, B_in, t_in, fs, gw_depth, station):
    """GEC6 general eq 5-14 (AASHTO N-factors, shape + gw factors). Net allowable ksf."""
    B = B_in / 12.0
    Df = (42.0) / 12.0  # bearing depth, ft below grade
    phi = PHI1
    Nc, Nq, Ng = n_factors(phi)
    L = WALL_L if station == 77.0 else B
    sq = 1 + (B/L) * Nq / Nc if L > B else 1.0
    sg = 1 - 0.4 * min(B / L, 1.0)
    CWr, CWq = gw_factors(gw_depth, B, Df)
    gamma = GAMMA1 / 1000.0  # ksf
    # buoyant below water table not needed for unit-weight term with CW factors
    q = gamma * Df * CWq
    qult = C1_ * Nc * sq + q * Nq + 0.5 * gamma * B * Ng * sg * CWr
    qnet = qult - q * CWq if CWr < 1.0 else qult - q
    qnet = qult - (GAMMA1/1000.0 * Df)  # net = gross - surcharge
    return qnet / fs

def q_allow_em1905(pad, B_in, t_in, fs, gw_depth, station):
    """EM 1110-1-1905 style general capacity (modified USACE) net allowable ksf."""
    B = B_in / 12.0
    Df = 42.0 / 12.0
    phi = math.radians(PHI1)
    Nq = math.exp(math.pi * math.tan(phi)) * math.tan(math.pi/4 + phi/2)**2
    Nc = (Nq - 1) / math.tan(phi)
    Ng = 2.0 * (Nq + 1) * math.tan(phi) * 0.5  # approximate: use 1.5 gamma B Ng with Nq+1 form
    L = WALL_L if station == 77.0 else B
    Fc = 1 + (B/L) * (Nq - 1) * (Nq / ((Nq-1))) ** 0 if L > B else 1.0
    Fq = 1 + (B/L) * math.tan(phi) * (Nq - 1) / Nc * 0 if L > B else 1.0
    gamma = GAMMA1 / 1000.0
    CWr, CWq = gw_factors(gw_depth, B, Df)
    qsur = gamma * Df
    qult = C1_ * Nc * Fc + qsur * Nq * CWq + 0.5 * gamma * B * Ng * sg_shape(B, L, phi) * CWr
    qnet = qult - qsur
    return qnet / fs

def sg_shape(B, L, phi):
    return 1.0

# ---------------- settlement: layered elastic, 2:1 ----------------
def settlement_unimproved(pad, B_in, q_psf, station, z_below_base_start=0.0):
    """q_psf net pressure; integrate from z_below_base_start down to max(4B,40) ft.
    Returns (settlement_in, dict of layer sums)."""
    B = B_in / 12.0
    L = WALL_L if station == 77.0 else B
    deep = max(4.0 * B, 40.0)
    base1 = stratum1_base(pad, station) - 42.0/12.0   # ft below base of footing
    es = ES[pad]
    top = z_below_base_start
    n = int(round((deep - top) / 0.25))
    s = 0.0
    for i in range(n):
        z = top + (i + 0.5) * 0.25
        if z < base1:
            Es = es[0]
        elif z < base1 + T2[pad]:
            Es = es[1]
        else:
            Es = es[2]
        ds = q_psf * B * L / ((B + z) * (L + z)) * 0.25 / (Es * 1000.0)
        s += ds
    return s * 12.0, {"deep_ft": deep, "base1_ft": base1}

def settlement_improved(pad, B_in, q_psf, station, depth_ft):
    """Two-layer GEC13: suz = qg/kg ; slz below treatment depth with reduced pressure qs."""
    B = B_in / 12.0
    L = WALL_L if station == 77.0 else L_ = B
    L = B
    Ra = 0.33
    ns = NS
    qg_psf = q_psf * ns / (ns * Ra - Ra + 1.0)
    qg_psi = qg_psf / 144.0
    kg = KG[pad] * 12.0  # pci -> psi over unit? treated: kg[pci]*12 = k/in? see note
    suz_in = qg_psi / (kg / 144.0) if False else qg_psf / (KG[pad] * 144.0 / 12.0)
    # units: qg in psf, kg in pci treated as psi*144/12 per GEC13 worked example convention
    suz_in = qg_psf / 144.0 / (KG[pad] / 12.0)
    qs_psf = q_psf * (1.0 - Ra) / (ns * Ra - Ra + 1.0)
    slz_in, _ = settlement_unimproved(pad, B_in, qs_psf, station, depth_ft)
    return suz_in + slz_in, qg_psf, qs_psf, Ra

# ---------------- cost ----------------
def pad_cost(pad, Bdict, tdict, improved, piers):
    """Bdict/tag->width in; tdict tag->thickness in; piers dict tag->count or None."""
    total = 0.0
    exc_vol = 0.0; conc_vol = 0.0; rebar_wt = 0.0
    d_exc = 42.0/12.0 + max(tdict.values())/12.0
    for tag, B in Bdict.items():
        L = WALL_L if tag == "W1" else B
        b_in, l_in = B, L * 12.0
        wroom = 2.0 * 12.0
        w_exc = b_in + wroom
        l_exc = l_in + wroom
        area = w_exc * l_exc / 144.0
        dep_below4 = max(0.0, d_exc - 4.0)
        extra = 2.0 * 1.5 * dep_below4
        exc_vol += area * 4.0 + (w_exc/12.0 + extra) * (l_exc/12.0 + extra) * dep_below4
        conc_vol += (b_in/12.0) * (l_in/12.0) * (tdict[tag]/12.0)
        rho = max(rebar_ratio.get(tag, 0.0), 0.0018)
        rebar_wt += 2.0 * rho * conc_vol * 1728.0 * 490.0 / 1728.0
    backfill = exc_vol - conc_vol
    gw = GW[pad]
    dew_days = 3.0 * math.ceil(max(0.0, d_exc - gw))
    fc = FC_ASSIGN[pad]
    total = (conc_vol * CP_C[str(fc)] + rebar_wt * CP_REBAR + exc_vol * CP_EXC
             + backfill * CP_BACKFILL + dew_days * CP_DEWATER)
    if improved:
        for tag, cnt in piers.items():
            total += cnt * depth_t[pad] * PIER_UNIT
        plat = sum((b/12.0) * ((WALL_L if tag=="W1" else b/12.0)) for tag, b in Bdict.items()) / 9.0
        total += plat * PLATFORM_UNIT
        total += MODTEST_UNIT
    return total

rebar_ratio = {}
FC_ASSIGN = {}
depth_t = {}

# ---------------- driver per pad ----------------
def design_pad(pad, use_improved):
    global rebar_ratio, FC_ASSIGN, depth_t
    fs = FS_OCC[pad]
    gw = GW[pad]
    results = {}
    # choose concrete
    cls = sulfate_class(SULFATE[pad])
    fmin = max(FC_MIN[cls], 3000)
    fc = min([f for f in FC_AVAILABLE if f >= fmin], key=lambda x: x)
    FC_ASSIGN[pad] = fc
    tags = ["F1","F2","F3","F4","F5","W1"]
    sizes = {}
    for tag in tags:
        P_S = load(pad, tag, "SERVICE_D_PLUS_L")[0] * 1000.0
        P_U = load(pad, tag, "STRENGTH_1.2D_1.6L")[0] * 1000.0
        if tag == "W1":
            L_in = WALL_L * 12.0
            e = load(pad, tag, "SERVICE_D_PLUS_L_PLUS_W")[2] / load(pad, tag, "SERVICE_D_PLUS_L_PLUS_W")[0]  # ft
            B = int(math.ceil(max(20, e * 6 * 12.0, 24.0) / 3.0) * 3)
        else:
            B = 24
        # find smallest 3-in width meeting all checks
        best = None
        for w in range(max(24, B), 24*24, 3):
            ok, info = check_foundation(pad, tag, w, use_improved, fs, gw)
            if ok:
                best = (w, info)
                break
        if best is None:
            w = 24*24
            ok, info = check_foundation(pad, tag, w, use_improved, fs, gw)
        sizes[tag] = best
    # piers
    piers = {}
    if use_improved:
        Ra = RA_MIN
        Dp = PIER_D
        S = Dp/12.0 + MIN_CLEAR/12.0  # 3.5 ft c-c square grid
        depth = depth_t.get(pad) or DEPTH_MIN
        for tag in tags:
            w = sizes[tag][0]
            L = WALL_L if tag == "W1" else w/12.0
            nx = int(math.floor((L*12.0 - Dp) / MIN_CLEAR + 1e-9))
            if nx < 1: nx = 1
            piers[tag] = max(nx, 1)
    results["sizes"] = sizes
    results["piers"] = piers
    return results

def check_foundation(pad, tag, w_in, improved, fs, gw):
    B = w_in / 12.0
    L = WALL_L if tag == "W1" else B
    sta = STATIONS[tag]
    P_S, H_S, M_S = load(pad, tag, "SERVICE_D_PLUS_L")
    P_U = load(pad, tag, "STRENGTH_1.2D_1.6L")[0]
    q_net = P_S * 1000.0 / (B * L)  # psf
    q_allow = q_allow_gsec6(pad, w_in, 0, fs, gw, sta)
    if q_net > q_allow:
        return False, {"fail": "bearing"}
    # thickness from two-way shear
    t = 12
    while True:
        d = t - 4.0
        if tag != "W1":
            a = COL_SIZE[tag] / 12.0
            Vu = q_u_ps = P_U * 1000.0
            b_w = (B + L - a) * 12.0
            Vcap = 0.65 * 2.0 * math.sqrt(fc_psi) * b_w * d / 1000.0  # kips
            Vreq = P_U - q_u_ps / 1000.0 * a * a
            if Vcap >= Vreq or d >= 60:
                break
        t += 3
    t = max(t, 12)
    # rebar
    if tag == "W1":
        M = P_U * 1000.0 / (L*12.0) * (B/2.0 - WALL_T/24.0)**2 / 2.0  # psi-in2... simplify: strip
        M = P_U * (B/2 - 0.5)**2 / 2.0 * 12.0  # kip-in per ft, then use L=24
        rho_req = M * 12.0 / (0.9 * 60000.0 * L * 12.0 * d)
    else:
        a = COL_SIZE[tag] / 12.0
        M = P_U * 1000.0 / (B*L) * B * ((B - a)/2.0)**2 * 12.0  # kip-in total /2
        M = P_U / (B*L) * (B/2 - a/2)**2 * B * L / 8.0 * 12.0 / L  # per width: kip-ft
        M = (P_U * 12.0 / (B * L)) * ( (B - a) ** 2 ) / 8.0 * L  # kip-in
        rho_req = M / (0.9 * 60000.0 * B * d)
    rho = max(rho_req, 0.0018)
    return True, {"q_net": q_net, "q_allow": q_allow, "t": t, "rho": rho}

if __name__ == "__main__":
    print("module loaded")
