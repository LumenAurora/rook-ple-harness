# Design Basis - Building A2 Roof Diaphragm Lateral Package

## 1. Governing documents
- EOR-NDDC-A2-S01 Rev 2 governs; Rev 0 superseded (Kzt=1.00, V=105 mph superseded by TS-2026-02 and NDDC-AHJ-014).
- NDDC-AHJ-014: V=115 mph, Risk III, Exposure C, Kd=0.85.
- TS-2026-02: Kzt=1.19.
- ALTA-2025-77: ground elevation for Ke.
- Federated model 2026 + SR-2026-118: as-built geometry governs over 2024 precast schedule (s5.3).

## 2. Conflicts resolved
Criteria Rev 0 values superseded; Hall B study (2023) is a different building and not used.

## 3. Table 1 - Deck zones
| Zone | Deck | G' (kip/in) | Capacity ASD (plf) | Area (sf) |
|---|---|---|---|---|
| Z1 | CDS-B36-G4 | 30.0 | TBD | 15600 |
| Z2 | CDS-B36-G3 | 24.0 | TBD | 8400 |
| Z3 | CDS-B36-G2 | 18.0 | TBD | 2280 |

## 4. Table 2 - Chord and collector lines
| Line | Section | Length (ft) |
|---|---|---|
| C-W | KRS-CH W1 | 240 |
| C-E | KRS-CH W1 | 180 |
| C-N1 | KRS-CH W1 | 240 |
| C-N2 | KRS-CH W1 | 180 |
| CC-1..CC-4 | KRS-CH C1 | see schedule |

## 5. Analysis method
DIAPH-MT 1.0 semi-rigid mesh per s9; L2 (H=5 ft) reported; L2-L3 convergence on W01 line W <= 5%.
All loads ASD (0.6W) per s3.3.
