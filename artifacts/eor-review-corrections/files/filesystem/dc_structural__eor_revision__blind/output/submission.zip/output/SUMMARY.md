# rook-generated submission summary

Building the reference-graph + closure computation and checking the CAD standard's ordering/identification tables: