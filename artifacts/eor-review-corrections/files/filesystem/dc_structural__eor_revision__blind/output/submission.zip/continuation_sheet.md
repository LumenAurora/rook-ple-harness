# Change Documentation for the Contracting Officer - Work Order 74213, Fleet Data Center Increment 2

## Bid Package BP-2 - Central Utility Plant and Site Utilities (solicitation N40085-26-R-2041)

Change number: CHG-003 (third change against this solicitation; two changes were previously issued).

The corrections to the EOR final design review of the Central Utility Plant and Site Utilities bid package are issued as a change to the solicitation already advertised on 6 July 2026. This change document is the continuation sheet for that change; it names the drawing-list document and the re-issued sheets that are delivered with it.

Drawing list: the regenerated drawing index for this change is sheet GI-001 (DRAWING INDEX), re-issued as part of this change; it lists every sheet in the change and its revision mark.

Re-issued sheets for this change:
  - C-101
  - C-301
  - G-001
  - GI-001
  - M-101
  - M-102
  - M-301
  - M-401
  - M-502
  - M-503
  - S-101
  - S-102
  - S-201
  - S-202
  - S-301
  - S-501
  - S-502

Delivered as 5 PDF bundles; total cost of this change: USD 71,950 (bundles 24,000; sheet re-issue 19,550; markup incorporation 0; added sheets 12,800; revision marks 3,600; overflow 0; non-concurrence documentation 12,000; solicitation-period extension 0).

## Bid Package BP-3 - Data Hall 210 Shell and Interiors (solicitation N40085-26-R-3018)

Statement: the BP-3 corrections are NOT issued as a change to a solicitation. The corrections are incorporated into the design before the solicitation is advertised (pre-advertisement reissue), so no change number is assigned and no continuation sheet is submitted for BP-3, per the Contracting Officer memorandum of 26 August 2026, paragraph 2. The corrected package is advertised as the corrected design.
