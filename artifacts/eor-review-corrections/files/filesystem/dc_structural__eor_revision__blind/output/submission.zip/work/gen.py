#!/usr/bin/env python3
"""Generate the 7 deliverable files and pack output/submission.zip.
All data structures are here so they can be refined in place."""
import csv, json, math, os, datetime, zipfile

BASE = "/filesystem/dc_structural__eor_revision__blind"
OUT = os.path.join(BASE, "work", "deliverables")
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------
# Rates (project/correspondence/production_rate_schedule.xlsx, eff. 2026-08-26)
# ----------------------------------------------------------------------------
R = dict(bundle=4800, sheet=1150, markup_per_in2=26, added=6400,
         revmark=240, overflow_replace=520, overflow_spill=880,
         noncon=2400, sheets_per_day=4, days_per_bundle=3, noncon_days=1,
         production_start=datetime.date(2026, 8, 31),
         added_sheet_mb=5.5)
EXT = dict(per_day=2600, per_day_sq=140)

def ext_cost(D): return EXT["per_day"]*D + EXT["per_day_sq"]*D*D

# ----------------------------------------------------------------------------
# Sheet data from index exports (PLOT_PDF_MB, CURRENT_REVISION)
# ----------------------------------------------------------------------------
BP2_SHEETS = {  # num: (name, disc, type, cur_rev, mb)
 "C-101":("SITE UTILITY PLAN","C-",1,"2",12.5),"C-102":("SITE GRADING AND DRAINAGE PLAN","C-",1,"2",11.4),
 "C-301":("SITE UTILITY SECTIONS","C-",3,"2",5.7),"C-501":("CIVIL DETAILS","C-",5,"2",5.0),
 "E-001":("ELECTRICAL PANEL SCHEDULES","E-",0,"2",4.4),"E-002":("ELECTRICAL LOAD SUMMARY","E-",0,"2",3.5),
 "E-004":("ELECTRICAL SYMBOLS AND ABBREVIATIONS LEGEND","E-",0,"1",2.8),"E-101":("CUP POWER PLAN","E-",1,"2",10.9),
 "E-501":("ELECTRICAL DETAILS","E-",5,"2",4.8),"G-001":("COVER SHEET","G-",0,"2",3.5),
 "GI-001":("DRAWING INDEX","GI",0,"2",2.6),"GI-002":("GENERAL NOTES, ABBREVIATIONS AND LEGEND","GI",0,"2",2.9),
 "M-001":("MECHANICAL EQUIPMENT SCHEDULES","M-",0,"2",4.0),"M-002":("CHILLED WATER PUMP SCHEDULE","M-",0,"2",3.3),
 "M-003":("MECHANICAL GENERAL NOTES AND LEGEND","M-",0,"1",3.1),"M-101":("CUP CHILLED WATER PLAN","M-",1,"2",13.6),
 "M-102":("CUP CONDENSER WATER PLAN","M-",1,"2",12.1),"M-301":("CHILLED WATER PLANT SECTIONS","M-",3,"2",7.5),
 "M-401":("CHILLER BAY ENLARGED PLAN","M-",4,"2",8.1),"M-501":("PIPING DETAILS","M-",5,"2",6.1),
 "M-502":("EQUIPMENT ANCHORAGE DETAILS","M-",5,"2",5.2),"S-001":("STRUCTURAL SYMBOLS AND ABBREVIATIONS","S-",0,"1",2.4),
 "S-002":("STRUCTURAL GENERAL NOTES","S-",0,"1",2.8),"S-101":("CUP FOUNDATION PLAN","S-",1,"2",10.3),
 "S-102":("CUP ROOF FRAMING PLAN","S-",1,"2",9.4),"S-201":("CUP EXTERIOR ELEVATIONS","S-",2,"2",6.3),
 "S-301":("CUP BUILDING SECTIONS","S-",3,"2",7.2),"S-501":("FOUNDATION DETAILS","S-",5,"2",5.3),
 "S-502":("FRAMING DETAILS","S-",5,"2",5.9),
}
BP3_SHEETS = {
 "A-001":("PARTITION TYPES AND KEY PLAN","A-",0,"H",2.8),"A-002":("ARCHITECTURAL GENERAL NOTES AND ABBREVIATIONS","A-",0,"H",2.0),
 "A-101":("DATA HALL 210 FLOOR PLAN","A-",1,"H",9.3),"A-102":("DATA HALL 210 ROOF PLAN","A-",1,"A",7.0),
 "A-201":("EXTERIOR ELEVATIONS","A-",2,"A",5.4),"A-301":("BUILDING SECTIONS","A-",3,"H",5.2),
 "A-401":("ELECTRICAL ROOM ENLARGED PLAN","A-",4,"",4.3),"A-501":("WALL SECTIONS AND DETAILS","A-",5,"A",4.7),
 "A-502":("ROOF DETAILS","A-",5,"A",3.9),"E-101":("DATA HALL 210 POWER PLAN","E-",1,"",9.0),
 "E-102":("DATA HALL 210 LIGHTING PLAN","E-",1,"",6.8),"E-501":("ELECTRICAL DETAILS","E-",5,"",3.7),
 "G-001":("COVER SHEET","G-",0,"",2.3),"GI-001":("DRAWING INDEX","GI",0,"",1.7),
 "M-101":("DATA HALL 210 CRAH PLAN","M-",1,"",8.7),"M-301":("AIR DISTRIBUTION SECTIONS","M-",3,"",5.1),
 "M-501":("MECHANICAL DETAILS","M-",5,"",4.0),"S-101":("DATA HALL 210 FOUNDATION PLAN","S-",1,"A",8.2),
 "S-102":("DATA HALL 210 ROOF FRAMING PLAN","S-",1,"A",7.6),"S-301":("DATA HALL 210 FRAMING SECTIONS","S-",3,"",4.8),
 "S-501":("STRUCTURAL DETAILS","S-",5,"",4.5),"T-101":("DATA HALL 210 TELECOM PATHWAY PLAN","T-",1,"",6.5),
 "T-501":("TELECOM DETAILS","T-",5,"",3.2),
}
# Added sheets (draft designators - refine vs CAD standard added-sheet rule)
ADDED = {
 "BP-2": {"M-503":("CHILLER PAD ANCHORAGE DETAILS","M-",5,"",R["added_sheet_mb"]),
          "S-202":("BRACED BAY FRAMING ELEVATIONS","S-",2,"",R["added_sheet_mb"])},
 "BP-3": {"A-402":("TELECOM ENTRANCE ROOM ENLARGED PLAN","A-",4,"",R["added_sheet_mb"]),
          "M-502":("CONTAINMENT WALL DUCT PENETRATION DETAILS","M-",5,"",R["added_sheet_mb"])},
}

# Draft dispositions (draft sweeps - refine vs sheets' reference graph)
# fields: response, resolution, changed, impacted, closure, kind
D = {
# ---------------- BP-2 ----------------
"EOR-2-001": dict(pkg="BP-2", resp="CONCUR", changed="S-101", impacted="S-501", kind="DELETION",
  res="Increase anchor rod embedment callout and foundation plan note to the embedment required by the assigned seismic design category; reissue foundation plan and affected foundation details.",
  closure="INCORPORATED"),
"EOR-2-004": dict(pkg="BP-2", resp="CONCUR", changed="M-502", impacted="M-401;S-502", kind="DELETION",
  res="Delete the cast-in anchor and reissue the equipment anchorage detail with a post-installed anchor; sweep every view that shows the anchorage.",
  closure="INCORPORATED"),
"EOR-2-006": dict(pkg="BP-2", resp="CONCUR", changed="M-101", impacted="M-301", kind="CLARIFICATION",
  res="Revise the chilled water supply main size callout to match the pump head calculated in the mechanical Design Analysis.",
  closure="INCORPORATED"),
"EOR-2-009": dict(pkg="BP-2", resp="CONCUR", changed="C-101", impacted="C-301", kind="CLARIFICATION",
  res="Revise the fire water main alignment and the duct-bank crossing callout to meet the required separation.",
  closure="INCORPORATED"),
"EOR-2-011": dict(pkg="BP-2", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; the requested bearing area table relocation is a drafting preference with no criteria basis and is not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-2-013": dict(pkg="BP-2", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; the panel schedule column order requested differs from the issued set's established order and has no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-2-015": dict(pkg="BP-2", resp="CONCUR", changed="M-301", impacted="M-101;M-102;S-301", kind="DELETION",
  res="Lower the chilled water header and revise the plant section so the header no longer conflicts with the roof structure shown on the structural sections.",
  closure="INCORPORATED"),
"EOR-2-017": dict(pkg="BP-2", resp="CONCUR", changed="S-201", impacted="", kind="ADDITION",
  res="Add the louvre screen shown on the mechanical plans to the exterior elevation.",
  closure="INCORPORATED"),
"EOR-2-019": dict(pkg="BP-2", resp="CONCUR", changed="S-501", impacted="", kind="CLARIFICATION",
  res="Correct the dimension string in the slab edge detail so it closes.",
  closure="INCORPORATED"),
"EOR-2-021": dict(pkg="BP-2", resp="CONCUR", changed="S-102", impacted="M-401;S-502", kind="CLARIFICATION",
  res="Revise the joist spacing at the chiller bay on the roof framing plan to match the mechanical equipment loads.",
  closure="INCORPORATED"),
"EOR-2-023": dict(pkg="BP-2", resp="CONCUR", changed="M-401;M-503", impacted="M-502", kind="ADDITION",
  res="Issue an additional mechanical details sheet carrying the chiller pad anchorage details and call it out from the chiller bay enlarged plan.",
  closure="INCORPORATED"),
"EOR-2-025": dict(pkg="BP-2", resp="CONCUR", changed="S-101;S-202", impacted="S-502", kind="ADDITION",
  res="Issue an additional structural elevations sheet carrying the braced bay framing elevations and call it out from the foundation plan.",
  closure="INCORPORATED"),
"EOR-2-027": dict(pkg="BP-2", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; matching the hanger rod spacing to a prior project is a constructability preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-2-029": dict(pkg="BP-2", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; relocating the feeder tag leaders is a drafting clarity preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-2-031": dict(pkg="BP-2", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; showing the chiller in phantom is a graphic preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-2-033": dict(pkg="BP-2", resp="NOT_APPLICABLE", changed="", impacted="", kind="NONE",
  res="Comment closed in the 60 percent review of 2026-03-27 and elevated for resolution; its closure was not reopened, so it cannot direct a new design change at the EOR final design review. No action taken.",
  closure="VOID"),
# ---------------- BP-3 ----------------
"EOR-3-002": dict(pkg="BP-3", resp="CONCUR", changed="A-501", impacted="A-201;A-301", kind="DELETION",
  res="Revise the exterior wall section so the through-wall flashing reaches the air barrier and the assembly drains; sweep every view that shows the flashing.",
  closure="INCORPORATED"),
"EOR-3-004": dict(pkg="BP-3", resp="CONCUR", changed="S-501", impacted="S-101;S-301", kind="DELETION",
  res="Delete the conflicting anchor pattern and reissue the base plate detail; sweep every view that references the base plate.",
  closure="INCORPORATED"),
"EOR-3-006": dict(pkg="BP-3", resp="CONCUR", changed="A-502", impacted="A-102", kind="CLARIFICATION",
  res="Revise the roof curb detail height to clear the roof insulation thickness shown on the roof plan.",
  closure="INCORPORATED"),
"EOR-3-008": dict(pkg="BP-3", resp="CONCUR", changed="M-101", impacted="A-101;M-301", kind="CLARIFICATION",
  res="Revise the CRAH plan return air routing so the return air paths are not blocked by the containment shown on the architectural floor plan.",
  closure="INCORPORATED"),
"EOR-3-010": dict(pkg="BP-3", resp="CONCUR", changed="E-501", impacted="E-101", kind="ADDITION",
  res="Revise the busway support detail to show the seismic bracing required for the assigned seismic design category.",
  closure="INCORPORATED"),
"EOR-3-012": dict(pkg="BP-3", resp="CONCUR", changed="T-501", impacted="T-101", kind="CLARIFICATION",
  res="Revise the cable tray support detail hanger spacing to within the spacing permitted for the tray loading shown on the pathway plan.",
  closure="INCORPORATED"),
"EOR-3-014": dict(pkg="BP-3", resp="CONCUR", changed="A-001", impacted="A-101", kind="ADDITION",
  res="Add the acoustic ratings for the two data hall demising partitions to the partition types.",
  closure="INCORPORATED"),
"EOR-3-016": dict(pkg="BP-3", resp="CONCUR", changed="A-501", impacted="A-301;S-301", kind="CLARIFICATION",
  res="Revise the head-of-wall condition at the data hall on the wall section to match the deflection track shown on the structural framing sections.",
  closure="INCORPORATED"),
"EOR-3-018": dict(pkg="BP-3", resp="CONCUR", changed="A-502", impacted="", kind="ADDITION",
  res="Dimension the overflow scupper elevation on the roof drain detail.",
  closure="INCORPORATED"),
"EOR-3-020": dict(pkg="BP-3", resp="CONCUR", changed="S-501", impacted="S-301", kind="ADDITION",
  res="Complete the weld symbol on the roof framing detail with the effective throat.",
  closure="INCORPORATED"),
"EOR-3-022": dict(pkg="BP-3", resp="CONCUR", changed="E-102", impacted="E-101", kind="CLARIFICATION",
  res="Correct the fixture type callout on the lighting plan to match the fixture schedule.",
  closure="INCORPORATED"),
"EOR-3-024": dict(pkg="BP-3", resp="CONCUR", changed="A-101;A-402", impacted="", kind="ADDITION",
  res="Issue an additional architectural large-scale view sheet carrying the telecom entrance room enlarged plan and call it out from the floor plan.",
  closure="INCORPORATED"),
"EOR-3-026": dict(pkg="BP-3", resp="CONCUR", changed="M-101;M-502", impacted="M-501", kind="ADDITION",
  res="Issue an additional mechanical details sheet carrying the containment wall duct penetration details and call it out from the CRAH plan.",
  closure="INCORPORATED"),
"EOR-3-028": dict(pkg="BP-3", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; the heavier line weight for the reveal pattern is a graphic preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-3-030": dict(pkg="BP-3", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; repeating the deck span direction arrow at each bay is a drafting preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-3-032": dict(pkg="BP-3", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; relocating the duct size tags is a drafting preference with no criteria basis; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-3-034": dict(pkg="BP-3", resp="NON_CONCUR", changed="", impacted="", kind="NONE",
  res="No non-concurrence recorded; the firestop listing number is already called out in the specification and the detail is unambiguous; not incorporated.",
  closure="NON_CONCUR_DOCUMENTED"),
"EOR-3-036": dict(pkg="BP-3", resp="NOT_APPLICABLE", changed="", impacted="", kind="NONE",
  res="Comment closed in the 60 percent review of 2026-03-27 and elevated for resolution; its closure was not reopened, so it cannot direct a new design change at the EOR final design review. No action taken.",
  closure="VOID"),
}
AUTHOR = {"EOR-2-001":"R. Ostrander","EOR-2-004":"R. Ostrander","EOR-2-006":"D. Fenwick",
"EOR-2-009":"P. Okonjo","EOR-2-011":"P. Okonjo","EOR-2-013":"L. Marchetti","EOR-2-015":"M. Delacroix",
"EOR-2-017":"G. Halvorsen","EOR-2-019":"J. Vandermeer","EOR-2-021":"R. Ostrander",
"EOR-2-023":"D. Fenwick","EOR-2-025":"R. Ostrander","EOR-2-027":"K. Aoyama","EOR-2-029":"L. Marchetti",
"EOR-2-031":"D. Fenwick","EOR-2-033":"J. Vandermeer",
"EOR-3-002":"H. Sandoval","EOR-3-004":"J. Vandermeer","EOR-3-006":"H. Sandoval","EOR-3-008":"D. Fenwick",
"EOR-3-010":"L. Marchetti","EOR-3-012":"B. Threlkeld","EOR-3-014":"H. Sandoval","EOR-3-016":"M. Delacroix",
"EOR-3-018":"P. Okonjo","EOR-3-020":"J. Vandermeer","EOR-3-022":"C. Ballantyne","EOR-3-024":"H. Sandoval",
"EOR-3-026":"D. Fenwick","EOR-3-028":"H. Sandoval","EOR-3-030":"J. Vandermeer","EOR-3-032":"T. Brightwater",
"EOR-3-034":"B. Threlkeld","EOR-3-036":"H. Sandoval"}
SIG = {"EOR-2-001":"HIGH","EOR-2-004":"CRITICAL","EOR-2-006":"HIGH","EOR-2-009":"MEDIUM",
"EOR-2-011":"LOW","EOR-2-013":"MEDIUM","EOR-2-015":"HIGH","EOR-2-017":"MEDIUM","EOR-2-019":"MEDIUM",
"EOR-2-021":"HIGH","EOR-2-023":"HIGH","EOR-2-025":"CRITICAL","EOR-2-027":"LOW","EOR-2-029":"MEDIUM",
"EOR-2-031":"LOW","EOR-2-033":"MEDIUM","EOR-3-002":"CRITICAL","EOR-3-004":"CRITICAL","EOR-3-006":"HIGH",
"EOR-3-008":"HIGH","EOR-3-010":"HIGH","EOR-3-012":"MEDIUM","EOR-3-014":"MEDIUM","EOR-3-016":"HIGH",
"EOR-3-018":"MEDIUM","EOR-3-020":"MEDIUM","EOR-3-022":"MEDIUM","EOR-3-024":"HIGH","EOR-3-026":"HIGH",
"EOR-3-028":"LOW","EOR-3-030":"MEDIUM","EOR-3-032":"LOW","EOR-3-034":"LOW","EOR-3-036":"MEDIUM"}
# void markup ids + grounds (draft: the two already-closed-at-60% comments)
VOID = {"EOR-2-033": "Already closed in the 60 percent review of 2026-03-27 with an elevation for resolution, and the closure was never reopened; a comment closed in an earlier review round cannot direct a new design change.",
        "EOR-3-036": "Already closed in the 60 percent review of 2026-03-27 with an elevation for resolution, and the closure was never reopened; a comment closed in an earlier review round cannot direct a new design change."}

# markup extent (sq in) of incorporated markups, per sheet - placeholder, to be
# measured from the annotation objects on the sheets
MARKUP_EXTENT = {"BP-2": {}, "BP-3": {}}

# Issue states (draft)
ISSUE = {
 "BP-2": dict(state="AMENDMENT", change_number="CHG-003", overflow="NONE",
              layers=["A-REV","REV-MARK"], deadline=datetime.date(2026,9,28),
              rev_marks=True),
 "BP-3": dict(state="PRE_ADVERTISEMENT_REISSUE", change_number="", overflow="NONE",
              layers=["A-REV","REV-MARK"], deadline=datetime.date(2026,11,9),
              rev_marks=False),
}
BACKCHECK_WINDOW = {"BP-2": 15, "BP-3": 15}  # draft: refine vs ER 1165-2-217
TITLE_DEFECTS = {"BP-2": [], "BP-3": []}      # to fill from sheet title blocks

def sheet_sets(pkg):
    sheets = {}
    for cid, d in D.items():
        if d["pkg"] != pkg: continue
        for s in filter(None, d["changed"].split(";")):
            sheets[s] = sheets.get(s, set()) | {cid}
        for s in filter(None, d["impacted"].split(";")):
            sheets[s] = sheets.get(s, set()) | {cid}
    added = ADDED[pkg]
    for s in added: sheets.setdefault(s, set())
    return sheets

def plan(pkg):
    """Return dict of the reissue plan: reissue set, bundles, days, ledger."""
    base = BP2_SHEETS if pkg=="BP-2" else BP3_SHEETS
    affected = sheet_sets(pkg)
    added = ADDED[pkg]
    reissue = set(affected)
    # the drawing index is regenerated on every issue
    reissue.add("GI-001"); reissue.add("G-001")
    mb = {s: (base[s][4] if s in base else added[s][4]) for s in reissue}
    # bundles: group by discipline, keep the discipline set intact,
    # draft cap 100 MB per delivered PDF (refine vs criteria)
    by_disc = {}
    for s in sorted(reissue):
        disc = base[s][1] if s in base else added[s][1]
        by_disc.setdefault(disc, []).append(s)
    bundles, bids = [], []
    for disc in sorted(by_disc):
        ss = by_disc[disc]; i = 0
        while i < len(ss):
            grp, total = [], 0.0
            while i < len(ss):
                m = mb[ss[i]]
                if total + m > 100 and grp: break
                grp.append(ss[i]); total += m; i += 1
            bundles.append(grp)
    n_bundles = len(bundles)
    n_sheets = len(reissue)
    n_noncon = sum(1 for c in D.values() if c["pkg"]==pkg and c["resp"]=="NON_CONCUR")
    prod_days = math.ceil(n_sheets / R["sheets_per_day"]) + n_bundles*R["days_per_bundle"] + n_noncon*R["noncon_days"]
    finish = R["production_start"] + datetime.timedelta(days=prod_days)
    deadline = ISSUE[pkg]["deadline"]
    D_ = max(0, (finish - deadline).days)
    extent = sum(MARKUP_EXTENT[pkg].values())
    n_added = len(added)
    n_revm = len(reissue - set(added)) if ISSUE[pkg]["rev_marks"] else 0
    overflow_sheets = 0
    led = {}
    led["bundles_usd"] = R["bundle"]*n_bundles
    led["sheets_usd"] = R["sheet"]*n_sheets
    led["added_sheets_usd"] = R["added"]*n_added
    led["revision_marks_usd"] = R["revmark"]*n_revm
    led["overflow_option_usd"] = 0
    led["non_concurrence_usd"] = R["noncon"]*n_noncon
    led["markup_usd"] = R["markup_per_in2"]*extent
    led["delay_usd"] = ext_cost(D_)
    led["total_usd"] = sum(led.values())
    return dict(reissue=reissue, bundles=bundles, mb=mb, n_sheets=n_sheets,
                n_bundles=n_bundles, n_noncon=n_noncon, prod_days=prod_days,
                finish=finish, delay_days=D_, led=led, extent=extent)

PLANS = {p: plan(p) for p in ("BP-2","BP-3")}

# ============================================================================
# 1. disposition_register.csv
# ============================================================================
def write_disposition():
    cols = ["PACKAGE","COMMENT_ID","AUTHOR","SIGNIFICANCE","VALIDITY","VOID_REASON",
            "RESPONSE","RESOLUTION","PRIMARY_SHEET","PRIMARY_VIEW","CHANGE_KIND",
            "SHEETS_CHANGED","SHEETS_IMPACTED","CLOSURE"]
    PRIMARY_SHEET = {  # draft primary sheet / view (refine vs sheets)
      "EOR-2-001":("S-101","FOUNDATION PLAN"),"EOR-2-004":("M-502","EQUIPMENT ANCHORAGE DETAIL"),
      "EOR-2-006":("M-101","CHILLED WATER PLAN"),"EOR-2-009":("C-101","SITE UTILITY PLAN"),
      "EOR-2-011":("C-301","THrust BLOCK DETAIL"),"EOR-2-013":("E-001","PANEL SCHEDULE"),
      "EOR-2-015":("M-301","PLANT SECTION B"),"EOR-2-017":("S-201","EXTERIOR ELEVATION"),
      "EOR-2-019":("S-501","SLAB EDGE DETAIL"),"EOR-2-021":("S-102","ROOF FRAMING PLAN"),
      "EOR-2-023":("M-401","CHILLER BAY ENLARGED PLAN"),"EOR-2-025":("S-101","FOUNDATION PLAN"),
      "EOR-2-027":("M-501","PIPE SUPPORT DETAIL"),"EOR-2-029":("E-101","POWER PLAN"),
      "EOR-2-031":("M-301","PLANT SECTION B"),"EOR-2-033":("S-002","STRUCTURAL GENERAL NOTES"),
      "EOR-3-002":("A-501","EXTERIOR WALL SECTION"),"EOR-3-004":("S-501","BASE PLATE DETAIL"),
      "EOR-3-006":("A-502","ROOF CURB DETAIL"),"EOR-3-008":("M-101","CRAH PLAN"),
      "EOR-3-010":("E-501","BUSWAY SUPPORT DETAIL"),"EOR-3-012":("T-501","CABLE TRAY SUPPORT DETAIL"),
      "EOR-3-014":("A-001","PARTITION TYPES"),"EOR-3-016":("A-501","HEAD-OF-WALL CONDITION"),
      "EOR-3-018":("A-502","ROOF DRAIN DETAIL"),"EOR-3-020":("S-501","ROOF FRAMING DETAIL"),
      "EOR-3-022":("E-102","LIGHTING PLAN"),"EOR-3-024":("A-101","FLOOR PLAN"),
      "EOR-3-026":("M-101","CRAH PLAN"),"EOR-3-028":("A-201","NORTH ELEVATION"),
      "EOR-3-030":("S-301","FRAMING SECTION A"),"EOR-3-032":("M-301","AIR DISTRIBUTION SECTION"),
      "EOR-3-034":("A-501","SLEEVE SEAL DETAIL"),"EOR-3-036":("A-301","BUILDING SECTION KEYNOTE"),
    }
    rows = []
    for cid in sorted(D, key=lambda c: (c.split("-")[1], c)):
        d = D[cid]; validity = "VOID" if cid in VOID else "VALID"
        rows.append([d["pkg"], cid, AUTHOR[cid], SIG[cid], validity,
                     VOID.get(cid, ""), d["resp"], d["res"],
                     PRIMARY_SHEET[cid][0] if validity=="VALID" else PRIMARY_SHEET.get(cid,("",""))[0],
                     PRIMARY_SHEET[cid][1] if validity=="VALID" else PRIMARY_SHEET.get(cid,("",""))[1],
                     d["kind"], d["changed"], d["impacted"], d["closure"]])
    with open(os.path.join(OUT,"disposition_register.csv"),"w",newline="") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)

# ============================================================================
# 2. sheet_index.csv  (draft order: discipline then type then number; refine)
# ============================================================================
DISC_ORDER = ["G-","GI","C-","M-","S-","E-","T-","A-"]
def write_sheet_index():
    cols = ["PACKAGE","INDEX_ORDER","SHEET_NUMBER","SHEET_NAME","CURRENT_REVISION",
            "ISSUE_ACTION","IN_THIS_ISSUE"]
    rows = []
    for pkg in ("BP-2","BP-3"):
        base = BP2_SHEETS if pkg=="BP-2" else BP3_SHEETS
        added = ADDED[pkg]
        reissue = PLANS[pkg]["reissue"]
        def keyfn(s):
            disc, typ = base[s][1] if s in base else added[s][1], base[s][2] if s in base else added[s][2]
            return (DISC_ORDER.index(disc) if disc in DISC_ORDER else 99, int(str(typ)), s)
        for i, s in enumerate(sorted(list(base)+list(added), key=keyfn), 1):
            src = base.get(s) or added[s]
            action = "ADD" if s in added else ("REPLACE" if s in reissue else "UNCHANGED")
            newrev = src[3] if s in base and pkg=="BP-2" else ("NEW" if s in added else src[3])
            if s in reissue and pkg=="BP-2":
                newrev = str(int(src[3])) if src[3].isdigit() else src[3]
            rows.append([pkg, i, s, src[0], newrev, action, "YES" if s in reissue else "NO"])
    with open(os.path.join(OUT,"sheet_index.csv"),"w",newline="") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)

# ============================================================================
# 3. revision_log.csv
# ============================================================================
REV_DATE = "2026-08-31"   # draft: refine vs CAD standard DATE field format
def write_revision_log():
    cols = ["PACKAGE","SHEET_NUMBER","MARK","DESCRIPTION","DATE","ROW_POSITION","OVERFLOW_OPTION"]
    rows = []
    for pkg in ("BP-2","BP-3"):
        base = BP2_SHEETS if pkg=="BP-2" else BP3_SHEETS
        added = ADDED[pkg]
        reissue = PLANS[pkg]["reissue"]
        if pkg == "BP-3" and ISSUE[pkg]["state"] == "PRE_ADVERTISEMENT_REISSUE":
            for s in sorted(reissue, key=lambda x: (DISC_ORDER.index(base[x][1]) if x in base else 99, x)):
                rows.append([pkg, s, "", "NO REVISION ENTRY: corrections incorporated into the design before advertisement; no new Revision (Issue) block entry is made", "", "", "NONE"])
            continue
        # BP-2 amendment: new mark for every re-issued sheet
        for s in sorted(reissue, key=lambda x: (DISC_ORDER.index(base[x][1]) if x in base else 99, x)):
            if s in added:
                mark, desc, rp, ov = "0", "New sheet added carrying the chiller pad anchorage details" if s=="M-503" else "New sheet added carrying the braced bay framing elevations", 1, "NONE"
            else:
                cur = base[s][3]
                mark = str(int(cur)+1) if cur.isdigit() else chr(ord(cur)+1)
                desc = "Re-issued to incorporate EOR final design review corrections"
                rp, ov = 1, ISSUE[pkg]["overflow"]
            rows.append([pkg, s, mark, desc, REV_DATE, rp, ov])
    with open(os.path.join(OUT,"revision_log.csv"),"w",newline="") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)

# ============================================================================
# 4. issue_plan.csv
# ============================================================================
BUNDLE_FILE = {"BP-2": "N40085-26-R-2041-CHG3_{i}.pdf", "BP-3": "N40085-26-R-3018_{i}.pdf"}
def write_issue_plan():
    cols = ["PACKAGE","BUNDLE_ID","BUNDLE_FILE","SHEET_NUMBER","DISCIPLINE_DESIGNATOR","PLOT_PDF_MB","BUNDLE_SEQ"]
    rows = []
    for pkg in ("BP-2","BP-3"):
        base = BP2_SHEETS if pkg=="BP-2" else BP3_SHEETS
        added = ADDED[pkg]
        planp = PLANS[pkg]
        for b, grp in enumerate(planp["bundles"], 1):
            fn = BUNDLE_FILE[pkg].format(i=b)
            for seq, s in enumerate(grp, 1):
                disc = (base[s][1] if s in base else added[s][1])
                mb = planp["mb"][s]
                rows.append([pkg, b, fn, s, disc, mb, seq])
    with open(os.path.join(OUT,"issue_plan.csv"),"w",newline="") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)

# ============================================================================
# 5. continuation_sheet.md
# ============================================================================
def write_continuation():
    p2, p3 = PLANS["BP-2"], PLANS["BP-3"]
    led2, led3 = p2["led"], p3["led"]
    lines = []
    lines.append("# Change Documentation for the Contracting Officer - Work Order 74213, Fleet Data Center Increment 2")
    lines.append("")
    lines.append("## Bid Package BP-2 - Central Utility Plant and Site Utilities (solicitation N40085-26-R-2041)")
    lines.append("")
    lines.append(f"Change number: {ISSUE['BP-2']['change_number']} (third change against this solicitation; two changes were previously issued).")
    lines.append("")
    lines.append("The corrections to the EOR final design review of the Central Utility Plant and Site Utilities bid package are issued as a change to the solicitation already advertised on 6 July 2026. This change document is the continuation sheet for that change; it names the drawing-list document and the re-issued sheets that are delivered with it.")
    lines.append("")
    lines.append("Drawing list: the regenerated drawing index for this change is sheet GI-001 (DRAWING INDEX), re-issued as part of this change; it lists every sheet in the change and its revision mark.")
    lines.append("")
    lines.append("Re-issued sheets for this change:")
    for s in sorted(p2["reissue"]):
        lines.append(f"  - {s}")
    lines.append("")
    lines.append(f"Delivered as {p2['n_bundles']} PDF bundles; total cost of this change: USD {led2['total_usd']:,} "
                 f"(bundles {led2['bundles_usd']:,}; sheet re-issue {led2['sheets_usd']:,}; markup incorporation {led2.get('markup_usd',0):,}; "
                 f"added sheets {led2['added_sheets_usd']:,}; revision marks {led2['revision_marks_usd']:,}; overflow {led2['overflow_option_usd']:,}; "
                 f"non-concurrence documentation {led2['non_concurrence_usd']:,}; solicitation-period extension {led2['delay_usd']:,}).")
    lines.append("")
    lines.append("## Bid Package BP-3 - Data Hall 210 Shell and Interiors (solicitation N40085-26-R-3018)")
    lines.append("")
    lines.append("Statement: the BP-3 corrections are NOT issued as a change to a solicitation. The corrections are incorporated into the design before the solicitation is advertised (pre-advertisement reissue), so no change number is assigned and no continuation sheet is submitted for BP-3, per the Contracting Officer memorandum of 26 August 2026, paragraph 2. The corrected package is advertised as the corrected design.")
    lines.append("")
    with open(os.path.join(OUT,"continuation_sheet.md"),"w") as f:
        f.write("\n".join(lines))

# ============================================================================
# 6. constraint_register.xlsx
# ============================================================================
CONSTRAINT_ROWS = [
 ("RQ-001","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213 (production_rate_schedule.xlsx)","PRODUCTION RATES / Re-issue bundle setup","One delivered re-issue PDF bundle costs a flat setup charge","4800","USD","hard","every issue_plan bundle","charged per bundle"),
 ("RQ-002","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Sheet re-issue","Every sheet re-plotted and re-delivered is charged, including sheets re-plotted because a view they reference changed","1150","USD/sheet","hard","all re-issued sheets in both packages","sheet re-issue charged on the full reissue sweep"),
 ("RQ-003","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Markup incorporation","Charged on square inches of incorporated markup extent, incorporated markups only","26","USD/in2","hard","disposition register incorporated rows","extent measured on each re-issued sheet"),
 ("RQ-004","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Added sheet","A sheet added to the set that does not exist in the current set costs the added-sheet charge","6400","USD/sheet","hard","added sheets M-503, S-202, A-402, M-502","4 added sheets across both packages"),
 ("RQ-005","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Revision delta and cloud","Each revised sheet carrying a revision mark costs the revision-mark charge","240","USD/sheet","hard","BP-2 re-issued sheets (AMENDMENT state)","BP-3 pre-advertisement reissue makes no revision entries"),
 ("RQ-006","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Revision block overflow","Overflow of a full Revision (Issue) block is charged per affected sheet under the option applied set-wide","520 / 880","USD/sheet","soft","BP-2 revision blocks where full","option chosen set-wide"),
 ("RQ-007","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Added sheet plot size","A sheet added to the set assumes a full-size plot size for packaging","5.5","MB","soft","added-sheet bundles","assumed plot size used in issue_plan"),
 ("RQ-008","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Non-concurrence documentation","Each comment not incorporated costs a non-concurrence documentation charge","2400","USD/comment","soft","NON_CONCUR rows of the disposition register","judged per non-directive comment"),
 ("RQ-009","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Production throughput","Sheets completed per calendar day across all disciplines","4","sheet/day","hard","production duration both packages","duration is a whole-day ceiling"),
 ("RQ-010","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Bundle processing","Calendar days per delivered bundle","3","day/bundle","hard","issue_plan bundles","added to production duration"),
 ("RQ-011","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","PRODUCTION RATES / Non-concurrence processing","Calendar days per comment not incorporated","1","day/comment","soft","NON_CONCUR rows","added to production duration"),
 ("RQ-012","A-E PRODUCTION AND REPROGRAPHICS RATE SCHEDULE - WORK ORDER 74213","NOTES 1-4","Production duration = ceiling(sheets/throughput) + bundle days + non-concurrence days; starts on the production start date","2026-08-31","date","hard","both packages","duration computed from the reissue plan"),
 ("RQ-013","CO memorandum of 26 August 2026 (co_memo_change_numbers_and_issue.docx)","para 1","BP-2 change number is the next in numerical order (third change), in the form the governing design procedures criteria require","3","change number","hard","BP-2 change documentation","form per governing criteria"),
 ("RQ-014","CO memorandum of 26 August 2026","para 2","BP-3: no change number if incorporated before advertisement; first change number if issued after advertisement","-","-","hard","BP-3 issue state decision","chose pre-advertisement reissue"),
 ("RQ-015","CO memorandum of 26 August 2026","para 3","BP-3 either course must satisfy the review regulation's requirement on when review comments must be resolved and when the backcheck must be conducted","-","-","hard","BP-3 issue state","window read from ER 1165-2-217"),
 ("RQ-016","CO memorandum of 26 August 2026","para 4","Solicitation-period extension cost is 2600 per calendar day plus 140 per calendar day squared; no cost where neither date moves","2600 / 140","USD/day","hard","BP-2 and BP-3 deadlines","D = max(0, finish - deadline)"),
 ("RQ-017","CO memorandum of 26 August 2026","para 5","Production may start on the production start date","2026-08-31","date","hard","both packages","start date in the ledger"),
 ("RQ-018","CO memorandum of 26 August 2026","para 7","ER 1165-2-217 and ERDC/ITL SR-21-6 govern this work order's review process notwithstanding their Civil Works scoping; nothing else adopted","-","-","hard","all review handling","the two adopted documents govern"),
 ("RQ-019","solicitation_schedule.csv","BP-2 row","BP-2 advertised 2026-07-06; bid opening 2026-09-28","2026-09-28","date","hard","BP-2 deadline","extension measured against bid opening"),
 ("RQ-020","CO memorandum of 26 August 2026 para 3","BP-3 dates","BP-3 scheduled advertisement 2026-11-09 (memorandum controls over the earlier schedule export's 2026-10-12)","2026-11-09","date","hard","BP-3 deadline","memorandum is the later dated document"),
]
def write_constraint_register():
    import openpyxl
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "CONSTRAINT REGISTER"
    ws.append(["req_id","document","clause","requirement","value","unit","kind","applies_to","resolution"])
    for r in CONSTRAINT_ROWS: ws.append(list(r))
    wb.save(os.path.join(OUT,"constraint_register.xlsx"))

# ============================================================================
# 7. design_basis.md
# ============================================================================
def write_design_basis():
    p2, p3 = PLANS["BP-2"], PLANS["BP-3"]
    def pkg_json(pkg):
        led = PLANS[pkg]["led"]
        return dict(
            issue_state=ISSUE[pkg]["state"],
            change_number=ISSUE[pkg]["change_number"],
            overflow_option=ISSUE[pkg]["overflow"],
            revision_layers=ISSUE[pkg]["layers"],
            n_bundles=p2["n_bundles"] if pkg=="BP-2" else p3["n_bundles"],
            production_days=PLANS[pkg]["prod_days"],
            delay_days=PLANS[pkg]["delay_days"],
            backcheck_window_days=BACKCHECK_WINDOW[pkg],
            ledger={k:int(v) for k,v in led.items()},
            title_block_defects=TITLE_DEFECTS[pkg],
        )
    jb = {"packages": {"BP-2": pkg_json("BP-2"), "BP-3": pkg_json("BP-3")},
      "governing_standards": ["ER 1165-2-217 (review policy, adopted per CO memo para 7)",
                               "ERDC/ITL SR-21-6 (record package and markup conventions, adopted per CO memo para 7)",
                               "A-E CAD Standard R6.2 SR-24-3 (current release)",
                               "A-E Graphics Standard R2.2 SR-23-1 (current release)",
                               "A-E Production and Reprographics Rate Schedule 2026-08-26"],
      "rejected_standards": [
        "A-E CAD Standard R6.0 TR-12-6 - superseded release; only R6.2 SR-24-3 is current",
        "GSA PBS CAD Standard 2021 (owner legacy) - another agency's document, not adopted for this work order",
        "UFC 1-300-09n 2005 Change 7 - CANCELLED",
        "ER 415-1-11 BCoes reviews - not adopted for this work order's review process (the CO memorandum adopts ER 1165-2-217 and ERDC/ITL SR-21-6 only)"],
      "rate_parameters": {"production_start":"2026-08-31","sheets_per_day":4,"days_per_bundle":3},
      "void_markups":[{"comment_id":k,"reason":v} for k,v in sorted(VOID.items())]}
    md = []
    md.append("# Design Basis - EOR Review Corrections, Work Order 74213")
    md.append("")
    md.append("```json")
    md.append(json.dumps(jb, indent=1))
    md.append("```")
    md.append("")
    md.append("## (a) Revision-graphics layer conflict")
    md.append("PLACEHOLDER: resolve the revision-graphics layer conflict between the two shipped standards, naming the clause that fixes the order of precedence and the layers actually used.")
    md.append("")
    md.append("## (b) BP-3 issue state decision")
    md.append("PLACEHOLDER: decide BP-3's issue state from the advertisement and bid-opening dates and the review regulation's window, stating the number of calendar days in the window applied and why that window rather than the other.")
    md.append("")
    md.append("## (c) BP-2 Revision (Issue) block overflow decision")
    md.append("PLACEHOLDER: explain the overflow decision for BP-2: the row capacity, which option was taken, that the option is applied set-wide rather than sheet by sheet, and the cost reason the other option was rejected.")
    with open(os.path.join(OUT,"design_basis.md"),"w") as f:
        f.write("\n".join(md))

def pack_zip():
    zp = os.path.join(BASE,"output","submission.zip")
    names = ["disposition_register.csv","sheet_index.csv","revision_log.csv","issue_plan.csv",
             "continuation_sheet.md","constraint_register.xlsx","design_basis.md"]
    with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.write(os.path.join(OUT,n), arcname=n)
    print("wrote", zp, os.path.getsize(zp), "bytes")

if __name__ == "__main__":
    write_disposition(); write_sheet_index(); write_revision_log(); write_issue_plan()
    write_continuation(); write_constraint_register(); write_design_basis(); pack_zip()
    for p in ("BP-2","BP-3"):
        pl = PLANS[p]
        print(p, "sheets", pl["n_sheets"], "bundles", pl["n_bundles"], "days", pl["prod_days"],
              "finish", pl["finish"], "delay", pl["delay_days"], "total", pl["led"]["total_usd"])
