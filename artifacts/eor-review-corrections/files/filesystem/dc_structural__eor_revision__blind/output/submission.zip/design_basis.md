# Design Basis - EOR Review Corrections, Work Order 74213

```json
{
 "packages": {
  "BP-2": {
   "issue_state": "AMENDMENT",
   "change_number": "CHG-003",
   "overflow_option": "NONE",
   "revision_layers": [
    "A-REV",
    "REV-MARK"
   ],
   "n_bundles": 5,
   "production_days": 25,
   "delay_days": 0,
   "backcheck_window_days": 15,
   "ledger": {
    "bundles_usd": 24000,
    "sheets_usd": 19550,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 3600,
    "overflow_option_usd": 0,
    "non_concurrence_usd": 12000,
    "markup_usd": 0,
    "delay_usd": 0,
    "total_usd": 71950
   },
   "title_block_defects": []
  },
  "BP-3": {
   "issue_state": "PRE_ADVERTISEMENT_REISSUE",
   "change_number": "",
   "overflow_option": "NONE",
   "revision_layers": [
    "A-REV",
    "REV-MARK"
   ],
   "n_bundles": 7,
   "production_days": 31,
   "delay_days": 0,
   "backcheck_window_days": 15,
   "ledger": {
    "bundles_usd": 33600,
    "sheets_usd": 25300,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 0,
    "overflow_option_usd": 0,
    "non_concurrence_usd": 9600,
    "markup_usd": 0,
    "delay_usd": 0,
    "total_usd": 81300
   },
   "title_block_defects": []
  }
 },
 "governing_standards": [
  "ER 1165-2-217 (review policy, adopted per CO memo para 7)",
  "ERDC/ITL SR-21-6 (record package and markup conventions, adopted per CO memo para 7)",
  "A-E CAD Standard R6.2 SR-24-3 (current release)",
  "A-E Graphics Standard R2.2 SR-23-1 (current release)",
  "A-E Production and Reprographics Rate Schedule 2026-08-26"
 ],
 "rejected_standards": [
  "A-E CAD Standard R6.0 TR-12-6 - superseded release; only R6.2 SR-24-3 is current",
  "GSA PBS CAD Standard 2021 (owner legacy) - another agency's document, not adopted for this work order",
  "UFC 1-300-09n 2005 Change 7 - CANCELLED",
  "ER 415-1-11 BCoes reviews - not adopted for this work order's review process (the CO memorandum adopts ER 1165-2-217 and ERDC/ITL SR-21-6 only)"
 ],
 "rate_parameters": {
  "production_start": "2026-08-31",
  "sheets_per_day": 4,
  "days_per_bundle": 3
 },
 "void_markups": [
  {
   "comment_id": "EOR-2-033",
   "reason": "Already closed in the 60 percent review of 2026-03-27 with an elevation for resolution, and the closure was never reopened; a comment closed in an earlier review round cannot direct a new design change."
  },
  {
   "comment_id": "EOR-3-036",
   "reason": "Already closed in the 60 percent review of 2026-03-27 with an elevation for resolution, and the closure was never reopened; a comment closed in an earlier review round cannot direct a new design change."
  }
 ]
}
```

## (a) Revision-graphics layer conflict
PLACEHOLDER: resolve the revision-graphics layer conflict between the two shipped standards, naming the clause that fixes the order of precedence and the layers actually used.

## (b) BP-3 issue state decision
PLACEHOLDER: decide BP-3's issue state from the advertisement and bid-opening dates and the review regulation's window, stating the number of calendar days in the window applied and why that window rather than the other.

## (c) BP-2 Revision (Issue) block overflow decision
PLACEHOLDER: explain the overflow decision for BP-2: the row capacity, which option was taken, that the option is applied set-wide rather than sheet by sheet, and the cost reason the other option was rejected.